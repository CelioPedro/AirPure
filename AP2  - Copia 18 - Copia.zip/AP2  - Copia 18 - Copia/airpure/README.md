# AirPure - Purificadores de Ar Modernos

Uma aplicação web responsiva e profissional para apresentação e venda de purificadores de ar, desenvolvida com arquitetura modular e melhores práticas de desenvolvimento.

## 🚀 Quick Start

Para visualizar o website corretamente, execute o servidor de desenvolvimento:

```bash
cd airpure
npm run dev
```

Abra http://localhost:3000 no navegador. Isso garante que as imagens e funcionalidades JavaScript funcionem corretamente.

### ⚠️ Importante sobre Servidor Local

**Não abra os arquivos HTML diretamente no navegador** (file://). Sempre use um servidor HTTP local para:

- Carregar imagens corretamente
- Funcionalidades JavaScript funcionarem
- Evitar erros de CORS

## 🚀 Características

- **Design Responsivo**: Interface adaptável para desktop, tablet e mobile
- **Arquitetura Modular**: Código organizado em módulos ES6 reutilizáveis
- **Performance Otimizada**: Carregamento eficiente com lazy loading e cache
- **Acessibilidade**: Suporte completo para tecnologias assistivas
- **SEO Otimizado**: Estrutura semântica e meta tags apropriadas
- **PWA Ready**: Preparado para instalação como Progressive Web App

## 📁 Estrutura do Projeto

```
airpure/
├── src/
│   ├── components/          # Componentes modulares
│   │   ├── navigation.js    # Gerenciamento de navegação
│   │   ├── animations.js    # Sistema de animações
│   │   ├── products.js      # Gerenciamento de produtos
│   │   ├── cart.js          # Sistema de carrinho
│   │   ├── modals.js        # Modais (login e detalhes)
│   │   ├── faq.js           # Sistema FAQ
│   │   ├── hero-slider.js   # Slider do hero
│   │   └── product-details.js # Detalhes do produto
│   ├── utils/               # Utilitários
│   │   └── dom-utils.js     # Utilitários DOM
│   ├── styles/              # Estilos SCSS
│   │   ├── components/      # Componentes de estilo
│   │   ├── main.scss        # Arquivo principal SCSS
│   │   └── variables.scss   # Variáveis SCSS
│   ├── types/               # Definições de tipos
│   ├── config.js            # Configuração centralizada
│   ├── index.html           # Página principal
│   └── js/
│       └── main.js          # Ponto de entrada da aplicação
├── 1010-final/              # Versão final compilada
├── package.json             # Dependências e scripts
├── vite.config.js           # Configuração Vite
└── README.md               # Documentação
```

## 🛠️ Tecnologias Utilizadas

- **Frontend**: HTML5, SCSS/CSS3, JavaScript ES6+
- **Build Tool**: Vite
- **Package Manager**: npm
- **Version Control**: Git
- **Linting**: ESLint
- **Formatting**: Prettier

## 📦 Instalação e Uso

### Pré-requisitos

- Node.js (versão 16 ou superior)
- npm ou yarn

### Instalação

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/airpure.git
cd airpure
```

2. Instale as dependências:
```bash
npm install
```

3. Inicie o servidor de desenvolvimento:
```bash
npm run dev
```

4. Abra seu navegador em `http://localhost:5173`

### Build para Produção

```bash
npm run build
```

### Preview da Build

```bash
npm run preview
```

## 🏗️ Arquitetura

### Sistema Modular

A aplicação utiliza uma arquitetura modular baseada em ES6 modules:

- **Componentes**: Cada funcionalidade é um módulo independente
- **Utilitários**: Funções auxiliares compartilhadas
- **Configuração**: Configurações centralizadas
- **Tipos**: Definições de tipos para melhor documentação

### Padrões de Desenvolvimento

- **BEM Methodology**: Para organização de CSS
- **JSDoc**: Documentação de código
- **ESLint**: Padronização de código
- **Semantic HTML**: Estrutura semântica

## 🎯 Funcionalidades

### Navegação
- Menu responsivo com hamburger
- Smooth scrolling para âncoras
- Indicador de seção ativa

### Produtos
- Filtros por categoria
- Modal de detalhes do produto
- Sistema de carrinho de compras
- Animações de interação

### Interface
- Slider automático no hero
- Animações de scroll
- FAQ interativo
- Modais responsivos

### Performance
- Lazy loading de imagens
- Cache inteligente
- Otimização de assets
- Code splitting

## 🔧 Configuração

### Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto:

```env
NODE_ENV=development
VITE_API_URL=https://api.airpure.com
VITE_ANALYTICS_ID=GA_MEASUREMENT_ID
```

### Personalização

#### Cores
Edite `src/styles/variables.scss` para personalizar as cores:

```scss
$primary-color: #007bff;
$secondary-color: #6c757d;
$accent-color: #28a745;
```

#### Configurações
Modifique `src/config.js` para ajustar comportamentos:

```javascript
export const CONFIG = {
  ANIMATION: {
    DURATION: 300,
    EASING: 'ease-out'
  },
  UI: {
    MOBILE_BREAKPOINT: 768
  }
};
```

## 📱 Responsividade

A aplicação é totalmente responsiva com breakpoints:

- **Mobile**: < 768px
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

## ♿ Acessibilidade

- Suporte completo para leitores de tela
- Navegação por teclado
- Contraste adequado de cores
- Estrutura semântica HTML5

## 🔍 SEO

- Meta tags otimizadas
- Estrutura de dados JSON-LD
- URLs amigáveis
- Performance otimizada

## 🧪 Testes

```bash
# Executar testes
npm run test

# Testes com coverage
npm run test:coverage

# Testes E2E
npm run test:e2e
```

## 🚀 Deploy

### Netlify

1. Conecte seu repositório no Netlify
2. Configure o comando de build: `npm run build`
3. Defina o diretório de publicação: `dist`

### Vercel

1. Importe o projeto no Vercel
2. Configure o comando de build: `npm run build`
3. O deploy será automático

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📝 Licença

Este projeto está sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## 👥 Autores

- **Seu Nome** - *Desenvolvimento Inicial* - [seu-github](https://github.com/seu-usuario)

## 🙏 Agradecimentos

- Inspiração: [AirPure Design System](https://airpure.design)
- Ícones: [Heroicons](https://heroicons.com)
- Fontes: [Google Fonts](https://fonts.google.com)

## 📞 Suporte

Para suporte, envie um email para support@airpure.com ou abra uma issue no GitHub.

---

⭐ **Star este repositório se você gostou do projeto!**
