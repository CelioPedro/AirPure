# TODO: Remove Vite and Run on Live Server

## Steps to Complete
- [x] Remove vite.config.js file
- [x] Update package.json: remove Vite dependencies and scripts, add SCSS compilation script
- [x] Adjust src/index.html to remove module script and SCSS import
- [x] Adjust src/js/main.js to remove ES module imports (using compiled JS from 1010-final)
- [x] Provide instructions to run Live Server on 1010-final folder
- [x] Test the site running on Live Server
