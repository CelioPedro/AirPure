/**
 * DOM Utilities Module
 * Provides helper functions for DOM manipulation and event handling
 * @module DOMUtils
 */

export class DOMUtils {
  /**
   * Cache for DOM elements to improve performance
   * @private
   * @type {Map<string, Element|NodeList>}
   */
  static cache = new Map();

  /**
   * Get DOM element with caching for performance
   * @param {string} selector - CSS selector
   * @param {boolean} [multiple=false] - Return multiple elements
   * @returns {Element|NodeList|null}
   */
  static getElement(selector, multiple = false) {
    const cacheKey = `${selector}_${multiple}`;

    if (!this.cache.has(cacheKey)) {
      this.cache.set(
        cacheKey,
        multiple ? document.querySelectorAll(selector) : document.querySelector(selector)
      );
    }

    return this.cache.get(cacheKey);
  }

  /**
   * Add event listeners to multiple elements
   * @param {NodeList|Element} elements - Elements to attach listeners to
   * @param {string} event - Event type
   * @param {Function} handler - Event handler function
   */
  static addEventListeners(elements, event, handler) {
    if (!elements) return;

    const elementArray = elements.length !== undefined ? elements : [elements];

    elementArray.forEach(element => {
      if (element) {
        element.addEventListener(event, handler);
      }
    });
  }

  /**
   * Toggle CSS class on element
   * @param {Element} element - Target element
   * @param {string} className - Class to toggle
   */
  static toggleClass(element, className) {
    if (element) {
      element.classList.toggle(className);
    }
  }

  /**
   * Add CSS class to element
   * @param {Element} element - Target element
   * @param {string} className - Class to add
   */
  static addClass(element, className) {
    if (element) {
      element.classList.add(className);
    }
  }

  /**
   * Remove CSS class from element
   * @param {Element} element - Target element
   * @param {string} className - Class to remove
   */
  static removeClass(element, className) {
    if (element) {
      element.classList.remove(className);
    }
  }

  /**
   * Check if element has CSS class
   * @param {Element} element - Target element
   * @param {string} className - Class to check
   * @returns {boolean}
   */
  static hasClass(element, className) {
    return element ? element.classList.contains(className) : false;
  }

  /**
   * Set element attribute
   * @param {Element} element - Target element
   * @param {string} attribute - Attribute name
   * @param {string} value - Attribute value
   */
  static setAttribute(element, attribute, value) {
    if (element) {
      element.setAttribute(attribute, value);
    }
  }

  /**
   * Get element attribute
   * @param {Element} element - Target element
   * @param {string} attribute - Attribute name
   * @returns {string|null}
   */
  static getAttribute(element, attribute) {
    return element ? element.getAttribute(attribute) : null;
  }

  /**
   * Create HTML element with attributes and content
   * @param {string} tagName - HTML tag name
   * @param {Object} [attributes={}] - Element attributes
   * @param {string} [content=''] - Element inner content
   * @returns {Element}
   */
  static createElement(tagName, attributes = {}, content = '') {
    const element = document.createElement(tagName);

    Object.keys(attributes).forEach(attr => {
      element.setAttribute(attr, attributes[attr]);
    });

    if (content) {
      element.innerHTML = content;
    }

    return element;
  }

  /**
   * Smooth scroll to element
   * @param {Element|string} target - Target element or selector
   * @param {number} [offset=0] - Offset from top
   */
  static scrollTo(target, offset = 0) {
    const element = typeof target === 'string' ? this.getElement(target) : target;

    if (element) {
      const elementTop = element.offsetTop - offset;
      window.scrollTo({
        top: elementTop,
        behavior: 'smooth'
      });
    }
  }
}
