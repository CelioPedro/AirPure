/**
 * Type Definitions for AirPure Application
 * Provides type definitions and interfaces for better code organization
 * @module Types
 */

/**
 * @typedef {Object} Product
 * @property {string} id - Unique product identifier
 * @property {string} name - Product name
 * @property {string} price - Product price as string (e.g., "R$ 1.299")
 * @property {string} image - Product image URL
 * @property {string} description - Product description
 * @property {string[]} specifications - Array of product specifications
 * @property {Benefit[]} benefits - Array of product benefits
 * @property {FAQItem[]} faq - Array of FAQ items
 * @property {string} category - Product category
 * @property {number} quantity - Quantity in cart (optional)
 */

/**
 * @typedef {Object} Benefit
 * @property {string} icon - Benefit icon (emoji or symbol)
 * @property {string} title - Benefit title
 * @property {string} description - Benefit description
 */

/**
 * @typedef {Object} FAQItem
 * @property {string} question - FAQ question
 * @property {string} answer - FAQ answer
 */

/**
 * @typedef {Object} CartItem
 * @property {string} id - Cart item ID
 * @property {string} name - Item name
 * @property {string} price - Item price
 * @property {string} image - Item image URL
 * @property {number} quantity - Item quantity
 */

/**
 * @typedef {Object} User
 * @property {string} id - User ID
 * @property {string} email - User email
 * @property {string} name - User name
 * @property {boolean} isLoggedIn - Login status
 * @property {string} avatar - User avatar URL
 */

/**
 * @typedef {Object} AppConfig
 * @property {Object} APP - Application metadata
 * @property {Object} API - API configuration
 * @property {Object} SELECTORS - DOM selectors
 * @property {Object} ANIMATION - Animation settings
 * @property {Object} UI - UI settings
 * @property {Object} PRODUCTS - Product settings
 * @property {Object} STORAGE - Storage keys
 * @property {Object} FEATURES - Feature flags
 * @property {Object} SERVICES - External services
 * @property {Object} DEV - Development settings
 */

/**
 * @typedef {Object} ComponentState
 * @property {boolean} isInitialized - Whether component is initialized
 * @property {boolean} isLoading - Whether component is loading
 * @property {boolean} isVisible - Whether component is visible
 * @property {Object} data - Component data
 * @property {Error} error - Component error state
 */

/**
 * @typedef {Object} EventHandler
 * @property {string} event - Event type
 * @property {Function} handler - Event handler function
 * @property {boolean} once - Whether to handle event only once
 * @property {Object} options - Event listener options
 */

/**
 * @typedef {Object} AnimationConfig
 * @property {number} duration - Animation duration in milliseconds
 * @property {string} easing - Animation easing function
 * @property {number} delay - Animation delay in milliseconds
 * @property {boolean} loop - Whether animation should loop
 * @property {string} direction - Animation direction
 */

/**
 * @typedef {Object} ModalConfig
 * @property {string} id - Modal ID
 * @property {string} title - Modal title
 * @property {string} content - Modal content
 * @property {string[]} buttons - Modal buttons
 * @property {boolean} closable - Whether modal can be closed
 * @property {string} size - Modal size (small, medium, large)
 */

/**
 * @typedef {Object} FormField
 * @property {string} name - Field name
 * @property {string} type - Field type (text, email, password, etc.)
 * @property {string} label - Field label
 * @property {string} placeholder - Field placeholder
 * @property {boolean} required - Whether field is required
 * @property {string} value - Field value
 * @property {string} error - Field error message
 * @property {Object} validation - Field validation rules
 */

/**
 * @typedef {Object} APIResponse
 * @property {boolean} success - Whether request was successful
 * @property {Object} data - Response data
 * @property {string} message - Response message
 * @property {Error} error - Response error
 * @property {number} status - HTTP status code
 */

/**
 * @typedef {Object} StorageItem
 * @property {string} key - Storage key
 * @property {*} value - Storage value
 * @property {number} expires - Expiration timestamp
 * @property {string} type - Storage type (localStorage, sessionStorage)
 */

/**
 * @typedef {Object} ThemeConfig
 * @property {string} name - Theme name
 * @property {Object} colors - Theme colors
 * @property {Object} fonts - Theme fonts
 * @property {Object} spacing - Theme spacing
 * @property {Object} breakpoints - Theme breakpoints
 */

/**
 * @typedef {Object} NotificationConfig
 * @property {string} type - Notification type (success, error, warning, info)
 * @property {string} title - Notification title
 * @property {string} message - Notification message
 * @property {number} duration - Notification duration in milliseconds
 * @property {boolean} closable - Whether notification can be closed
 * @property {Function} onClose - Callback when notification is closed
 */

// Export empty object to make this a module
export default {};
