/**
 * Application Configuration
 * Centralized configuration for the AirPure application
 * @module Config
 */

export const CONFIG = {
  // Application metadata
  APP: {
    NAME: 'AirPure',
    VERSION: '2.0.0',
    DESCRIPTION: 'Purificadores de Ar Modernos - Website responsivo e profissional'
  },

  // API endpoints (for future use)
  API: {
    BASE_URL: process.env.NODE_ENV === 'production'
      ? 'https://api.airpure.com'
      : 'http://localhost:3000/api',
    ENDPOINTS: {
      PRODUCTS: '/products',
      CART: '/cart',
      CHECKOUT: '/checkout',
      USER: '/user'
    }
  },

  // DOM selectors
  SELECTORS: {
    // Navigation
    NAV_LINKS: 'a[href^="#"]',
    HEADER: '.header',
    HAMBURGER_TOGGLE: '.hamburger-toggle',
    HAMBURGER_NAV: '.hamburger-nav',
    DROPDOWN_TOGGLE: '.dropdown-toggle',
    DROPDOWN_MENU: '.dropdown-menu',
    CTA_BUTTON: '.cta-button',

    // Products
    FILTER_BUTTONS: '.filter-btn',
    PRODUCT_CARDS: '.product-card',
    PRODUCT_BUTTONS: '.product-button',
    PRODUCT_NAME: '.product-name',
    PRODUCT_PRICE: '.product-price',

    // Cart
    CART_ICON: '.cart-icon',
    CART_COUNT: '.cart-count',
    CART_MODAL: '.cart-modal',
    CART_ITEMS: '.cart-items',
    CART_TOTAL: '.cart-total',

    // Modals
    LOGIN_MODAL: '.login-modal',
    PRODUCT_MODAL: '.product-modal',

    // FAQ
    FAQ_ITEMS: '.faq-item',
    FAQ_QUESTIONS: '.faq-question',
    FAQ_ANSWERS: '.faq-answer',

    // Animations
    HERO_CONTENT: '.hero-content',
    HERO_IMAGE: '.hero-image',
    ANIMATED_ELEMENTS: '.fade-in, .tech-card, .benefit-card, .faq-item'
  },

  // Animation settings
  ANIMATION: {
    INTERSECTION_THRESHOLD: 0.1,
    INTERSECTION_ROOT_MARGIN: '0px 0px -50px 0px',
    STAGGER_DELAY: 0.1,
    PRODUCT_DELAY: 0,
    HERO_CONTENT_DELAY: 300,
    HERO_IMAGE_DELAY: 600,
    HERO_TRANSITION_DURATION: 0.8
  },

  // UI settings
  UI: {
    SCROLL_THRESHOLD: 50,
    MOBILE_BREAKPOINT: 1020,
    PURCHASE_FEEDBACK_DURATION: 2000,
    HAMBURGER_RESET_DELAY: 300,
    MODAL_FADE_DURATION: 300
  },

  // Product data
  PRODUCTS: {
    CATEGORIES: ['all', 'purifier', 'accessory', 'filter'],
    DEFAULT_CATEGORY: 'all'
  },

  // Local storage keys
  STORAGE: {
    CART: 'airpure-cart',
    USER_PREFERENCES: 'airpure-preferences',
    THEME: 'airpure-theme'
  },

  // Feature flags
  FEATURES: {
    ENABLE_ANIMATIONS: true,
    ENABLE_CART: true,
    ENABLE_LOGIN: true,
    ENABLE_PRODUCT_DETAILS: true,
    ENABLE_FAQ: true,
    ENABLE_SEARCH: false, // Future feature
    ENABLE_REVIEWS: false, // Future feature
    ENABLE_COMPARE: false  // Future feature
  },

  // External services
  SERVICES: {
    ANALYTICS: {
      ENABLED: false,
      ID: 'GA_MEASUREMENT_ID'
    },
    EMAIL: {
      SERVICE_ID: 'service_id',
      TEMPLATE_ID: 'template_id',
      PUBLIC_KEY: 'public_key'
    }
  },

  // Development settings
  DEV: {
    ENABLE_CONSOLE_LOGS: process.env.NODE_ENV !== 'production',
    ENABLE_DEBUG_MODE: process.env.NODE_ENV !== 'production',
    MOCK_API_RESPONSES: process.env.NODE_ENV !== 'production'
  }
};

// Environment-specific overrides
if (typeof window !== 'undefined') {
  // Browser-specific config
  CONFIG.UI.IS_MOBILE = window.innerWidth <= CONFIG.UI.MOBILE_BREAKPOINT;
  CONFIG.UI.IS_TOUCH_DEVICE = 'ontouchstart' in window;

  // Update on resize
  window.addEventListener('resize', () => {
    CONFIG.UI.IS_MOBILE = window.innerWidth <= CONFIG.UI.MOBILE_BREAKPOINT;
  });
}

export default CONFIG;
