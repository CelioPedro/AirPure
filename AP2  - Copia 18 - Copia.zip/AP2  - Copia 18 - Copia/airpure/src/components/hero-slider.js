/**
 * Hero Slider Component Module
 * Handles background image slider with smooth transitions
 * @module HeroSlider
 */

import { DOMUtils } from '../utils/dom-utils.js';

export class HeroSlider {
  /**
   * Configuration for hero slider
   * @private
   * @type {Object}
   */
  static config = {
    selectors: {
      HERO_SECTION: '.hero',
      SLIDER_CONTAINER: '.hero-slider-container'
    },
    settings: {
      IMAGES: [
        './images/HeroBG01.jpg',
        './images/HeroBG02.jpg',
        './images/HeroBG03.jpg',
        './images/HeroBG04.jpg'
      ],
      DISPLAY_DURATION: 6000, // 6 seconds
      TRANSITION_DURATION: 1500, // 1.5 seconds
      ZOOM_SCALE: 1.05
    }
  };

  /**
   * Slider state
   * @private
   * @type {Object}
   */
  static state = {
    currentIndex: 0,
    showingImg: null,
    hiddenImg: null,
    intervalId: null,
    isInitialized: false
  };

  /**
   * Initialize hero slider
   */
  static init() {
    const heroSection = DOMUtils.getElement(this.config.selectors.HERO_SECTION);

    if (!heroSection) {
      console.warn('Hero section not found. Slider disabled.');
      return;
    }

    this.createSliderContainer(heroSection);
    this.preloadImages();
    this.startSlider();

    this.state.isInitialized = true;
    console.log('Hero slider initialized');
  }

  /**
   * Create slider container and image elements
   * @private
   * @param {Element} heroSection - Hero section element
   */
  static createSliderContainer(heroSection) {
    // Create main container
    const container = DOMUtils.createElement('div', {
      class: 'hero-slider-container'
    });

    // Set container styles
    Object.assign(container.style, {
      position: 'absolute',
      top: '0',
      left: '0',
      width: '100%',
      height: '100%',
      overflow: 'hidden',
      zIndex: '0',
      backgroundColor: 'transparent'
    });

    // Create image elements
    const img1 = this.createImageElement();
    const img2 = this.createImageElement();

    container.appendChild(img1);
    container.appendChild(img2);

    // Add gradient overlay
    const gradientOverlay = this.createGradientOverlay();
    container.appendChild(gradientOverlay);

    // Set hero section styles
    Object.assign(heroSection.style, {
      position: 'relative',
      backgroundImage: 'none'
    });

    heroSection.appendChild(container);

    // Store references
    this.state.showingImg = img1;
    this.state.hiddenImg = img2;
  }

  /**
   * Create image element for slider
   * @private
   * @returns {Element}
   */
  static createImageElement() {
    const img = DOMUtils.createElement('div');

    Object.assign(img.style, {
      position: 'absolute',
      top: '0',
      left: '0',
      width: '100%',
      height: '100%',
      backgroundSize: 'cover',
      backgroundRepeat: 'no-repeat',
      backgroundPosition: 'center',
      filter: 'brightness(0.7) saturate(1.2)',
      transition: `opacity ${this.config.settings.TRANSITION_DURATION}ms linear, transform ${this.config.settings.DISPLAY_DURATION}ms linear`,
      willChange: 'opacity, transform'
    });

    return img;
  }

  /**
   * Create gradient overlay
   * @private
   * @returns {Element}
   */
  static createGradientOverlay() {
    const overlay = DOMUtils.createElement('div');

    Object.assign(overlay.style, {
      position: 'absolute',
      top: '0',
      left: '0',
      width: '100%',
      height: '100%',
      background: 'linear-gradient(135deg, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.4) 50%, rgba(0,0,0,0.6) 100%)',
      zIndex: '0',
      pointerEvents: 'none'
    });

    return overlay;
  }

  /**
   * Preload all slider images
   * @private
   */
  static preloadImages() {
    this.config.settings.IMAGES.forEach(src => {
      const img = new Image();
      img.src = src;
    });
  }

  /**
   * Set image for slider element
   * @private
   * @param {Element} element - Image element
   * @param {number} index - Image index
   */
  static setImage(element, index) {
    const imageUrl = this.config.settings.IMAGES[index];

    Object.assign(element.style, {
      transition: `opacity ${this.config.settings.TRANSITION_DURATION}ms linear, transform ${this.config.settings.DISPLAY_DURATION}ms linear`,
      backgroundImage: `url('${imageUrl}')`,
      opacity: '1',
      transform: 'scale(1)'
    });

    // Start zoom animation
    requestAnimationFrame(() => {
      element.style.transform = `scale(${this.config.settings.ZOOM_SCALE})`;
    });
  }

  /**
   * Perform crossfade transition
   * @private
   */
  static crossfade() {
    const nextIndex = (this.state.currentIndex + 1) % this.config.settings.IMAGES.length;

    // Prepare next image
    this.state.hiddenImg.style.transition = `opacity ${this.config.settings.TRANSITION_DURATION}ms linear`;
    this.state.hiddenImg.style.backgroundImage = `url('${this.config.settings.IMAGES[nextIndex]}')`;
    this.state.hiddenImg.style.opacity = '0';
    this.state.hiddenImg.style.transform = 'scale(1)';

    // Force reflow
    void this.state.hiddenImg.offsetWidth;

    // Fade in new image and fade out current
    this.state.hiddenImg.style.opacity = '1';
    this.state.showingImg.style.opacity = '0';

    // Swap references
    [this.state.showingImg, this.state.hiddenImg] = [this.state.hiddenImg, this.state.showingImg];

    // Update current index
    this.state.currentIndex = nextIndex;

    // Restart zoom for new image
    this.state.showingImg.style.transition = `opacity ${this.config.settings.TRANSITION_DURATION}ms linear, transform ${this.config.settings.DISPLAY_DURATION}ms linear`;
    this.state.showingImg.style.transform = `scale(${this.config.settings.ZOOM_SCALE})`;
  }

  /**
   * Start slider animation
   * @private
   */
  static startSlider() {
    // Set initial image
    this.setImage(this.state.showingImg, this.state.currentIndex);
    this.state.hiddenImg.style.opacity = '0';
    this.state.hiddenImg.style.transform = 'scale(1)';

    // Start interval
    this.state.intervalId = setInterval(() => {
      this.crossfade();
    }, this.config.settings.DISPLAY_DURATION);
  }

  /**
   * Stop slider animation
   */
  static stopSlider() {
    if (this.state.intervalId) {
      clearInterval(this.state.intervalId);
      this.state.intervalId = null;
    }
  }

  /**
   * Pause slider animation
   */
  static pauseSlider() {
    this.stopSlider();
  }

  /**
   * Resume slider animation
   */
  static resumeSlider() {
    if (!this.state.intervalId && this.state.isInitialized) {
      this.startSlider();
    }
  }

  /**
   * Go to specific slide
   * @param {number} index - Slide index
   */
  static goToSlide(index) {
    if (index < 0 || index >= this.config.settings.IMAGES.length) {
      return;
    }

    this.stopSlider();
    this.state.currentIndex = index;
    this.setImage(this.state.showingImg, index);
    this.startSlider();
  }

  /**
   * Get current slide index
   * @returns {number}
   */
  static getCurrentSlide() {
    return this.state.currentIndex;
  }

  /**
   * Get total number of slides
   * @returns {number}
   */
  static getTotalSlides() {
    return this.config.settings.IMAGES.length;
  }

  /**
   * Update slider settings
   * @param {Object} newSettings - New settings to apply
   */
  static updateSettings(newSettings) {
    Object.assign(this.config.settings, newSettings);
  }

  /**
   * Check if slider is initialized
   * @returns {boolean}
   */
  static isInitialized() {
    return this.state.isInitialized;
  }
}
