/**
 * Navigation Component Module
 * Handles navigation menu, hamburger menu, and smooth scrolling
 * @module Navigation
 */

import { DOMUtils } from '../utils/dom-utils.js';

export class NavigationManager {
  /**
   * Configuration object for navigation selectors and settings
   * @private
   * @type {Object}
   */
  static config = {
    selectors: {
      NAV_LINKS: 'a[href^="#"]',
      HEADER: '.header',
      HAMBURGER_TOGGLE: '.hamburger-toggle',
      HAMBURGER_NAV: '.hamburger-nav',
      DROPDOWN_TOGGLE: '.dropdown-toggle',
      DROPDOWN_MENU: '.dropdown-menu'
    },
    ui: {
      SCROLL_THRESHOLD: 50,
      MOBILE_BREAKPOINT: 1020,
      HAMBURGER_RESET_DELAY: 300
    }
  };

  /**
   * Initialize navigation functionality
   */
  static init() {
    this.bindEvents();
    this.handleScroll();
  }

  /**
   * Bind all navigation-related event listeners
   * @private
   */
  static bindEvents() {
    // Smooth scrolling for anchor links
    const navLinks = DOMUtils.getElement(this.config.selectors.NAV_LINKS, true);
    DOMUtils.addEventListeners(navLinks, 'click', this.handleNavClick.bind(this));

    // Hamburger menu toggle
    const hamburgerToggle = DOMUtils.getElement(this.config.selectors.HAMBURGER_TOGGLE);
    if (hamburgerToggle) {
      hamburgerToggle.addEventListener('click', this.toggleHamburgerMenu.bind(this));
    }

    // Dropdown menus
    const dropdownToggles = DOMUtils.getElement(this.config.selectors.DROPDOWN_TOGGLE, true);
    DOMUtils.addEventListeners(dropdownToggles, 'click', this.handleDropdownToggle.bind(this));

    // Scroll event for header styling
    window.addEventListener('scroll', this.handleScroll.bind(this));

    // Close hamburger menu on window resize
    window.addEventListener('resize', this.handleResize.bind(this));
  }

  /**
   * Handle navigation link clicks with smooth scrolling
   * @private
   * @param {Event} e - Click event
   */
  static handleNavClick(e) {
    e.preventDefault();

    const target = DOMUtils.getAttribute(e.currentTarget, 'href');
    if (target && target.startsWith('#')) {
      const targetElement = DOMUtils.getElement(target);
      if (targetElement) {
        DOMUtils.scrollTo(targetElement, 80); // Offset for fixed header

        // Close mobile menu if open
        this.closeHamburgerMenu();
      }
    }
  }

  /**
   * Toggle hamburger menu visibility
   * @private
   */
  static toggleHamburgerMenu() {
    const hamburgerNav = DOMUtils.getElement(this.config.selectors.HAMBURGER_NAV);
    const body = document.body;

    if (hamburgerNav) {
      const isOpen = DOMUtils.hasClass(hamburgerNav, 'show');

      if (isOpen) {
        this.closeHamburgerMenu();
      } else {
        this.openHamburgerMenu();
      }
    }
  }

  /**
   * Open hamburger menu
   * @private
   */
  static openHamburgerMenu() {
    const hamburgerNav = DOMUtils.getElement(this.config.selectors.HAMBURGER_NAV);
    const body = document.body;

    if (hamburgerNav) {
      DOMUtils.addClass(hamburgerNav, 'show');
      DOMUtils.addClass(body, 'menu-open');
    }
  }

  /**
   * Close hamburger menu
   * @private
   */
  static closeHamburgerMenu() {
    const hamburgerNav = DOMUtils.getElement(this.config.selectors.HAMBURGER_NAV);
    const body = document.body;

    if (hamburgerNav) {
      DOMUtils.removeClass(hamburgerNav, 'show');
      DOMUtils.removeClass(body, 'menu-open');
    }
  }

  /**
   * Handle dropdown menu toggle
   * @private
   * @param {Event} e - Click event
   */
  static handleDropdownToggle(e) {
    e.preventDefault();

    const toggle = e.currentTarget;
    const menu = toggle.nextElementSibling;

    if (menu) {
      DOMUtils.toggleClass(menu, 'show');
      DOMUtils.toggleClass(toggle, 'active');
    }
  }

  /**
   * Handle scroll events for header styling
   * @private
   */
  static handleScroll() {
    const header = DOMUtils.getElement(this.config.selectors.HEADER);
    const scrollY = window.scrollY;

    if (header) {
      if (scrollY > this.config.ui.SCROLL_THRESHOLD) {
        DOMUtils.addClass(header, 'scrolled');
      } else {
        DOMUtils.removeClass(header, 'scrolled');
      }
    }
  }

  /**
   * Handle window resize events
   * @private
   */
  static handleResize() {
    const width = window.innerWidth;

    // Close hamburger menu on desktop
    if (width > this.config.ui.MOBILE_BREAKPOINT) {
      this.closeHamburgerMenu();
    }
  }

  /**
   * Check if device is mobile
   * @returns {boolean}
   */
  static isMobile() {
    return window.innerWidth <= this.config.ui.MOBILE_BREAKPOINT;
  }
}
