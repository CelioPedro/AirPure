/**
 * Products Component Module
 * Handles product filtering, display, and interactions
 * @module Products
 */

import { DOMUtils } from '../utils/dom-utils.js';

export class ProductManager {
  /**
   * Configuration for product selectors and settings
   * @private
   * @type {Object}
   */
  static config = {
    selectors: {
      FILTER_BUTTONS: '.filter-btn',
      PRODUCT_CARDS: '.product-card',
      PRODUCT_BUTTONS: '.product-button',
      PRODUCT_NAME: '.product-name',
      PRODUCT_PRICE: '.product-price'
    },
    ui: {
      PURCHASE_FEEDBACK_DURATION: 2000
    }
  };

  /**
   * Current active filter
   * @private
   * @type {string}
   */
  static currentFilter = 'all';

  /**
   * Initialize product functionality
   */
  static init() {
    this.bindEvents();
    this.setupFilters();
  }

  /**
   * Bind product-related event listeners
   * @private
   */
  static bindEvents() {
    // Filter buttons
    const filterButtons = DOMUtils.getElement(this.config.selectors.FILTER_BUTTONS, true);
    DOMUtils.addEventListeners(filterButtons, 'click', this.handleFilterClick.bind(this));

    // Product buttons (buy/add to cart)
    const productButtons = DOMUtils.getElement(this.config.selectors.PRODUCT_BUTTONS, true);
    DOMUtils.addEventListeners(productButtons, 'click', this.handleProductClick.bind(this));
  }

  /**
   * Set up product filters
   * @private
   */
  static setupFilters() {
    const filterButtons = DOMUtils.getElement(this.config.selectors.FILTER_BUTTONS, true);

    if (filterButtons && filterButtons.length > 0) {
      // Set first filter as active by default
      DOMUtils.addClass(filterButtons[0], 'active');
    }
  }

  /**
   * Handle filter button clicks
   * @private
   * @param {Event} e - Click event
   */
  static handleFilterClick(e) {
    e.preventDefault();

    const button = e.currentTarget;
    const filterValue = DOMUtils.getAttribute(button, 'data-filter') || 'all';

    // Update active filter button
    this.updateActiveFilter(button);

    // Filter products
    this.filterProducts(filterValue);

    // Update current filter
    this.currentFilter = filterValue;
  }

  /**
   * Update active filter button styling
   * @private
   * @param {Element} activeButton - Button to mark as active
   */
  static updateActiveFilter(activeButton) {
    const filterButtons = DOMUtils.getElement(this.config.selectors.FILTER_BUTTONS, true);

    // Remove active class from all buttons
    filterButtons.forEach(btn => {
      DOMUtils.removeClass(btn, 'active');
    });

    // Add active class to clicked button
    DOMUtils.addClass(activeButton, 'active');
  }

  /**
   * Filter products based on category
   * @private
   * @param {string} filterValue - Filter value ('all', 'purifier', 'accessory', etc.)
   */
  static filterProducts(filterValue) {
    const productCards = DOMUtils.getElement(this.config.selectors.PRODUCT_CARDS, true);

    if (!productCards) return;

    productCards.forEach(card => {
      const productCategory = DOMUtils.getAttribute(card, 'data-category') || 'all';

      if (filterValue === 'all' || productCategory === filterValue) {
        DOMUtils.removeClass(card, 'hidden');
        DOMUtils.addClass(card, 'visible');
      } else {
        DOMUtils.removeClass(card, 'visible');
        DOMUtils.addClass(card, 'hidden');
      }
    });

    // Animate filtered products
    this.animateFilteredProducts();
  }

  /**
   * Animate products after filtering
   * @private
   */
  static animateFilteredProducts() {
    const visibleCards = DOMUtils.getElement('.product-card.visible', true);

    if (visibleCards) {
      visibleCards.forEach((card, index) => {
        // Stagger animation
        setTimeout(() => {
          DOMUtils.addClass(card, 'fade-in');
        }, index * 100);
      });
    }
  }

  /**
   * Handle product button clicks (buy/add to cart)
   * @private
   * @param {Event} e - Click event
   */
  static handleProductClick(e) {
    e.preventDefault();

    const button = e.currentTarget;
    const productCard = button.closest('.product-card');

    if (productCard) {
      const productName = DOMUtils.getElement(this.config.selectors.PRODUCT_NAME, false, productCard);
      const productPrice = DOMUtils.getElement(this.config.selectors.PRODUCT_PRICE, false, productCard);

      const productData = {
        name: productName ? productName.textContent : 'Produto',
        price: productPrice ? productPrice.textContent : 'R$ 0,00',
        id: DOMUtils.getAttribute(productCard, 'data-product-id') || Date.now().toString()
      };

      this.handlePurchase(productData, button);
    }
  }

  /**
   * Handle product purchase/add to cart
   * @private
   * @param {Object} productData - Product information
   * @param {Element} button - Button that was clicked
   */
  static handlePurchase(productData, button) {
    // Add loading state
    DOMUtils.addClass(button, 'loading');
    const originalText = button.textContent;
    button.textContent = 'Adicionando...';

    // Simulate API call delay
    setTimeout(() => {
      // Remove loading state
      DOMUtils.removeClass(button, 'loading');
      button.textContent = originalText;

      // Show success feedback
      this.showPurchaseFeedback(button, productData.name);

      // Add to cart (if cart system exists)
      this.addToCart(productData);

    }, 800);
  }

  /**
   * Show purchase feedback to user
   * @private
   * @param {Element} button - Button element
   * @param {string} productName - Name of purchased product
   */
  static showPurchaseFeedback(button, productName) {
    // Create feedback element
    const feedback = DOMUtils.createElement('div', {
      class: 'purchase-feedback'
    }, `${productName} adicionado ao carrinho!`);

    // Position feedback near button
    const buttonRect = button.getBoundingClientRect();
    DOMUtils.addClass(feedback, 'show');

    document.body.appendChild(feedback);

    // Position feedback
    feedback.style.position = 'fixed';
    feedback.style.left = `${buttonRect.left + buttonRect.width / 2}px`;
    feedback.style.top = `${buttonRect.top - 10}px`;
    feedback.style.transform = 'translateX(-50%)';

    // Remove feedback after delay
    setTimeout(() => {
      if (feedback.parentNode) {
        DOMUtils.removeClass(feedback, 'show');
        setTimeout(() => {
          document.body.removeChild(feedback);
        }, 300);
      }
    }, this.config.ui.PURCHASE_FEEDBACK_DURATION);
  }

  /**
   * Add product to cart
   * @private
   * @param {Object} productData - Product information
   */
  static addToCart(productData) {
    // Get existing cart from localStorage
    let cart = JSON.parse(localStorage.getItem('airpure-cart') || '[]');

    // Check if product already exists in cart
    const existingProduct = cart.find(item => item.id === productData.id);

    if (existingProduct) {
      existingProduct.quantity += 1;
    } else {
      cart.push({
        ...productData,
        quantity: 1
      });
    }

    // Save updated cart
    localStorage.setItem('airpure-cart', JSON.stringify(cart));

    // Update cart UI if cart component exists
    this.updateCartUI(cart);
  }

  /**
   * Update cart UI elements
   * @private
   * @param {Array} cart - Cart items
   */
  static updateCartUI(cart) {
    const cartCountElements = DOMUtils.getElement('.cart-count', true);

    if (cartCountElements) {
      const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

      cartCountElements.forEach(element => {
        element.textContent = totalItems;
        if (totalItems > 0) {
          DOMUtils.removeClass(element, 'hidden');
        } else {
          DOMUtils.addClass(element, 'hidden');
        }
      });
    }
  }

  /**
   * Get current filter value
   * @returns {string}
   */
  static getCurrentFilter() {
    return this.currentFilter;
  }

  /**
   * Reset product filters
   */
  static resetFilters() {
    this.currentFilter = 'all';
    this.filterProducts('all');

    // Reset active filter button
    const filterButtons = DOMUtils.getElement(this.config.selectors.FILTER_BUTTONS, true);
    if (filterButtons) {
      filterButtons.forEach(btn => {
        DOMUtils.removeClass(btn, 'active');
      });
      DOMUtils.addClass(filterButtons[0], 'active');
    }
  }
}
