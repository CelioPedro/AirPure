/**
 * Animation Component Module
 * Handles scroll-triggered animations and UI animations
 * @module Animations
 */

import { DOMUtils } from '../utils/dom-utils.js';

export class AnimationManager {
  /**
   * Configuration for animation settings
   * @private
   * @type {Object}
   */
  static config = {
    selectors: {
      ANIMATED_ELEMENTS: '.fade-in, .tech-card, .benefit-card, .faq-item'
    },
    animation: {
      INTERSECTION_THRESHOLD: 0.1,
      INTERSECTION_ROOT_MARGIN: '0px 0px -50px 0px',
      STAGGER_DELAY: 0.1
    }
  };

  /**
   * Intersection Observer instance
   * @private
   * @type {IntersectionObserver}
   */
  static observer = null;

  /**
   * Initialize animation system
   */
  static init() {
    this.setupIntersectionObserver();
    this.observeElements();
  }

  /**
   * Set up Intersection Observer for scroll animations
   * @private
   */
  static setupIntersectionObserver() {
    const options = {
      threshold: this.config.animation.INTERSECTION_THRESHOLD,
      rootMargin: this.config.animation.INTERSECTION_ROOT_MARGIN
    };

    this.observer = new IntersectionObserver((entries) => {
      entries.forEach((entry, index) => {
        if (entry.isIntersecting) {
          // Add staggered delay for multiple elements
          const delay = index * this.config.animation.STAGGER_DELAY;
          setTimeout(() => {
            DOMUtils.addClass(entry.target, 'animate');
          }, delay * 1000);

          // Stop observing after animation
          this.observer.unobserve(entry.target);
        }
      });
    }, options);
  }

  /**
   * Start observing animated elements
   * @private
   */
  static observeElements() {
    const elements = DOMUtils.getElement(this.config.selectors.ANIMATED_ELEMENTS, true);

    if (elements && elements.length > 0) {
      elements.forEach(element => {
        this.observer.observe(element);
      });
    }
  }

  /**
   * Add fade-in animation to element
   * @param {Element} element - Element to animate
   * @param {number} [delay=0] - Animation delay in milliseconds
   */
  static fadeIn(element, delay = 0) {
    if (!element) return;

    setTimeout(() => {
      DOMUtils.addClass(element, 'fade-in');
      DOMUtils.addClass(element, 'animate');
    }, delay);
  }

  /**
   * Animate element with slide effect
   * @param {Element} element - Element to animate
   * @param {string} direction - Slide direction ('left', 'right', 'up', 'down')
   * @param {number} [delay=0] - Animation delay in milliseconds
   */
  static slideIn(element, direction = 'up', delay = 0) {
    if (!element) return;

    const slideClass = `slide-in-${direction}`;
    DOMUtils.addClass(element, slideClass);

    setTimeout(() => {
      DOMUtils.addClass(element, 'animate');
    }, delay);
  }

  /**
   * Animate counter/number increment
   * @param {Element} element - Element containing the number
   * @param {number} targetValue - Final value to count to
   * @param {number} [duration=2000] - Animation duration in milliseconds
   */
  static animateCounter(element, targetValue, duration = 2000) {
    if (!element) return;

    const startValue = 0;
    const startTime = performance.now();

    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Easing function for smooth animation
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      const currentValue = Math.floor(startValue + (targetValue - startValue) * easeOutQuart);

      element.textContent = this.formatNumber(currentValue);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }

  /**
   * Format number with thousand separators
   * @private
   * @param {number} num - Number to format
   * @returns {string}
   */
  static formatNumber(num) {
    return num.toLocaleString('pt-BR');
  }

  /**
   * Create loading spinner animation
   * @param {Element} container - Container element
   * @returns {Element} Spinner element
   */
  static createSpinner(container) {
    const spinner = DOMUtils.createElement('div', {
      class: 'loading-spinner'
    });

    for (let i = 0; i < 3; i++) {
      const dot = DOMUtils.createElement('div', {
        class: 'spinner-dot'
      });
      spinner.appendChild(dot);
    }

    if (container) {
      container.appendChild(spinner);
    }

    return spinner;
  }

  /**
   * Remove loading spinner
   * @param {Element} spinner - Spinner element to remove
   */
  static removeSpinner(spinner) {
    if (spinner && spinner.parentNode) {
      spinner.parentNode.removeChild(spinner);
    }
  }

  /**
   * Animate element entrance with bounce effect
   * @param {Element} element - Element to animate
   * @param {number} [delay=0] - Animation delay in milliseconds
   */
  static bounceIn(element, delay = 0) {
    if (!element) return;

    DOMUtils.addClass(element, 'bounce-in');

    setTimeout(() => {
      DOMUtils.addClass(element, 'animate');
    }, delay);
  }

  /**
   * Pulse animation for attention-grabbing elements
   * @param {Element} element - Element to animate
   * @param {number} [duration=1000] - Pulse duration in milliseconds
   */
  static pulse(element, duration = 1000) {
    if (!element) return;

    DOMUtils.addClass(element, 'pulse');

    setTimeout(() => {
      DOMUtils.removeClass(element, 'pulse');
    }, duration);
  }
}
