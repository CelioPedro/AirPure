/**
 * FAQ Component Module
 * Handles frequently asked questions accordion functionality
 * @module FAQ
 */

import { DOMUtils } from '../utils/dom-utils.js';

export class FAQManager {
  /**
   * Configuration for FAQ settings
   * @private
   * @type {Object}
   */
  static config = {
    selectors: {
      FAQ_ITEMS: '.faq-item',
      FAQ_QUESTIONS: '.faq-question',
      FAQ_ANSWERS: '.faq-answer'
    }
  };

  /**
   * Initialize FAQ functionality
   */
  static init() {
    this.bindEvents();
  }

  /**
   * Bind FAQ-related event listeners
   * @private
   */
  static bindEvents() {
    const faqQuestions = DOMUtils.getElement(this.config.selectors.FAQ_QUESTIONS, true);
    DOMUtils.addEventListeners(faqQuestions, 'click', this.handleQuestionClick.bind(this));

    // Keyboard accessibility
    DOMUtils.addEventListeners(faqQuestions, 'keydown', this.handleKeyDown.bind(this));
  }

  /**
   * Handle FAQ question clicks
   * @private
   * @param {Event} e - Click event
   */
  static handleQuestionClick(e) {
    const question = e.currentTarget;
    const faqItem = question.closest('.faq-item');

    if (faqItem) {
      this.toggleFAQ(faqItem);
    }
  }

  /**
   * Handle keyboard events for accessibility
   * @private
   * @param {Event} e - Keyboard event
   */
  static handleKeyDown(e) {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      this.handleQuestionClick(e);
    }
  }

  /**
   * Toggle FAQ item open/closed state
   * @private
   * @param {Element} faqItem - FAQ item element
   */
  static toggleFAQ(faqItem) {
    const question = DOMUtils.getElement('.faq-question', false, faqItem);
    const answer = DOMUtils.getElement('.faq-answer', false, faqItem);

    if (!question || !answer) return;

    const isExpanded = DOMUtils.getAttribute(question, 'aria-expanded') === 'true';

    if (isExpanded) {
      this.closeFAQ(faqItem);
    } else {
      this.openFAQ(faqItem);
    }
  }

  /**
   * Open FAQ item
   * @private
   * @param {Element} faqItem - FAQ item element
   */
  static openFAQ(faqItem) {
    const question = DOMUtils.getElement('.faq-question', false, faqItem);
    const answer = DOMUtils.getElement('.faq-answer', false, faqItem);

    if (!question || !answer) return;

    // Update ARIA attributes
    DOMUtils.setAttribute(question, 'aria-expanded', 'true');

    // Add active class
    DOMUtils.addClass(faqItem, 'active');

    // Animate answer height
    const scrollHeight = answer.scrollHeight;
    answer.style.maxHeight = scrollHeight + 'px';

    // Smooth transition
    setTimeout(() => {
      answer.style.maxHeight = 'none';
    }, 300);
  }

  /**
   * Close FAQ item
   * @private
   * @param {Element} faqItem - FAQ item element
   */
  static closeFAQ(faqItem) {
    const question = DOMUtils.getElement('.faq-question', false, faqItem);
    const answer = DOMUtils.getElement('.faq-answer', false, faqItem);

    if (!question || !answer) return;

    // Update ARIA attributes
    DOMUtils.setAttribute(question, 'aria-expanded', 'false');

    // Remove active class
    DOMUtils.removeClass(faqItem, 'active');

    // Animate answer height
    answer.style.maxHeight = answer.scrollHeight + 'px';

    setTimeout(() => {
      answer.style.maxHeight = '0px';
    }, 10);
  }

  /**
   * Close all FAQ items
   */
  static closeAll() {
    const faqItems = DOMUtils.getElement(this.config.selectors.FAQ_ITEMS, true);

    if (faqItems) {
      faqItems.forEach(item => {
        this.closeFAQ(item);
      });
    }
  }

  /**
   * Open specific FAQ item by index
   * @param {number} index - FAQ item index (0-based)
   */
  static openByIndex(index) {
    const faqItems = DOMUtils.getElement(this.config.selectors.FAQ_ITEMS, true);

    if (faqItems && faqItems[index]) {
      this.openFAQ(faqItems[index]);
    }
  }

  /**
   * Get FAQ item count
   * @returns {number}
   */
  static getItemCount() {
    const faqItems = DOMUtils.getElement(this.config.selectors.FAQ_ITEMS, true);
    return faqItems ? faqItems.length : 0;
  }

  /**
   * Search FAQ items
   * @param {string} query - Search query
   */
  static search(query) {
    const faqItems = DOMUtils.getElement(this.config.selectors.FAQ_ITEMS, true);
    const lowerQuery = query.toLowerCase();

    if (faqItems) {
      faqItems.forEach(item => {
        const question = DOMUtils.getElement('.faq-question', false, item);
        const answer = DOMUtils.getElement('.faq-answer', false, item);

        if (question && answer) {
          const questionText = question.textContent.toLowerCase();
          const answerText = answer.textContent.toLowerCase();

          if (questionText.includes(lowerQuery) || answerText.includes(lowerQuery)) {
            DOMUtils.removeClass(item, 'hidden');
          } else {
            DOMUtils.addClass(item, 'hidden');
            this.closeFAQ(item); // Close hidden items
          }
        }
      });
    }
  }

  /**
   * Clear search and show all FAQ items
   */
  static clearSearch() {
    const faqItems = DOMUtils.getElement(this.config.selectors.FAQ_ITEMS, true);

    if (faqItems) {
      faqItems.forEach(item => {
        DOMUtils.removeClass(item, 'hidden');
      });
    }
  }

  /**
   * Add smooth animations to FAQ interactions
   * @private
   */
  static addAnimations() {
    const faqItems = DOMUtils.getElement(this.config.selectors.FAQ_ITEMS, true);

    if (faqItems) {
      faqItems.forEach((item, index) => {
        // Stagger initial animation
        setTimeout(() => {
          DOMUtils.addClass(item, 'fade-in');
        }, index * 100);
      });
    }
  }

  /**
   * Initialize with animations
   */
  static initWithAnimations() {
    this.init();
    // Delay animations to ensure DOM is ready
    setTimeout(() => {
      this.addAnimations();
    }, 100);
  }

  /**
   * Get FAQ data for dynamic content
   * @returns {Array} FAQ items data
   */
  static getFAQData() {
    return [
      {
        question: "Como funciona o AirPure?",
        answer: "O AirPure utiliza filtros HEPA avançados para capturar partículas nocivas do ar, combinados com sensores inteligentes que ajustam a purificação conforme a qualidade do ar ambiente."
      },
      {
        question: "Qual o tamanho ideal do ambiente?",
        answer: "Nossos purificadores são projetados para ambientes específicos: Compact (até 20m²), Mini (até 30m²), Silent (até 40m²), Wiiser (até 45m²), Zen (até 48m²) e Max (até 50m²)."
      },
      {
        question: "Precisa de manutenção frequente?",
        answer: "Recomendamos limpeza mensal dos filtros externos e substituição do filtro HEPA a cada 6-12 meses, dependendo do uso e qualidade do ar local."
      },
      {
        question: "É compatível com app móvel?",
        answer: "Sim, todos os modelos possuem controle via aplicativo móvel para iOS e Android, permitindo ajustes remotos e monitoramento em tempo real da qualidade do ar."
      },
      {
        question: "Qual a diferença entre os modelos?",
        answer: "Cada modelo oferece diferentes capacidades de purificação, níveis de ruído, consumo energético e recursos adicionais. O Max é o mais completo, enquanto o Compact é ideal para espaços menores."
      },
      {
        question: "O purificador elimina odores?",
        answer: "Sim, nossos purificadores incluem filtros de carvão ativado que neutralizam odores, fumos e compostos orgânicos voláteis (VOCs) presentes no ar."
      }
    ];
  }

  /**
   * Render FAQ items dynamically
   * @param {Array} [faqData] - FAQ data array
   */
  static renderFAQ(faqData = null) {
    const faqContainer = DOMUtils.getElement('.faq-container');
    if (!faqContainer) return;

    const data = faqData || this.getFAQData();
    faqContainer.innerHTML = '';

    data.forEach((item, index) => {
      const faqItem = DOMUtils.createElement('div', { class: 'faq-item' });

      const question = DOMUtils.createElement('button', {
        class: 'faq-question',
        'aria-expanded': 'false',
        'aria-controls': `faq-answer-${index}`
      }, item.question);

      const answer = DOMUtils.createElement('div', {
        class: 'faq-answer',
        id: `faq-answer-${index}`
      });

      const answerP = DOMUtils.createElement('p', {}, item.answer);
      answer.appendChild(answerP);

      faqItem.appendChild(question);
      faqItem.appendChild(answer);
      faqContainer.appendChild(faqItem);
    });

    // Re-bind events for new elements
    this.bindEvents();
  }
}
