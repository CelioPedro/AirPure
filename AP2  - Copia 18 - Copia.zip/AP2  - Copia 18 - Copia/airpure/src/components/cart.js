/**
 * Cart Component Module
 * Handles shopping cart functionality
 * @module Cart
 */

import { DOMUtils } from '../utils/dom-utils.js';

export class CartManager {
  /**
   * Cart items array
   * @private
   * @type {Array}
   */
  static cart = [];

  /**
   * DOM elements cache
   * @private
   * @type {Object}
   */
  static elements = {};

  /**
   * Initialize cart functionality
   */
  static init() {
    this.loadCart();
    this.cacheElements();
    this.bindEvents();
    this.renderCart();
  }

  /**
   * Cache DOM elements for performance
   * @private
   */
  static cacheElements() {
    this.elements = {
      cartIcon: DOMUtils.getElement('.cart-icon'),
      cartCount: DOMUtils.getElement('.cart-count'),
      cartModal: DOMUtils.getElement('.cart-modal'),
      cartItems: DOMUtils.getElement('.cart-items'),
      cartTotal: DOMUtils.getElement('.cart-total'),
      checkoutBtn: DOMUtils.getElement('.checkout-btn'),
      clearCartBtn: DOMUtils.getElement('.clear-cart-btn')
    };
  }

  /**
   * Bind cart-related event listeners
   * @private
   */
  static bindEvents() {
    // Cart icon click
    if (this.elements.cartIcon) {
      this.elements.cartIcon.addEventListener('click', this.toggleCart.bind(this));
    }

    // Checkout button
    if (this.elements.checkoutBtn) {
      this.elements.checkoutBtn.addEventListener('click', this.checkout.bind(this));
    }

    // Clear cart button
    if (this.elements.clearCartBtn) {
      this.elements.clearCartBtn.addEventListener('click', this.clearCart.bind(this));
    }

    // Close cart when clicking outside
    document.addEventListener('click', this.handleOutsideClick.bind(this));
  }

  /**
   * Load cart from localStorage
   * @private
   */
  static loadCart() {
    const savedCart = localStorage.getItem('airpure-cart');
    if (savedCart) {
      this.cart = JSON.parse(savedCart);
    }
  }

  /**
   * Save cart to localStorage
   * @private
   */
  static saveCart() {
    localStorage.setItem('airpure-cart', JSON.stringify(this.cart));
  }

  /**
   * Add item to cart
   * @param {Object} item - Item to add
   * @param {string} item.name - Item name
   * @param {string} item.price - Item price
   * @param {string} item.image - Item image URL
   * @param {number} [item.quantity=1] - Item quantity
   */
  static addItem(item) {
    const existingItem = this.cart.find(cartItem => cartItem.id === item.id);

    if (existingItem) {
      existingItem.quantity += item.quantity || 1;
    } else {
      this.cart.push({
        ...item,
        quantity: item.quantity || 1,
        id: item.id || Date.now().toString()
      });
    }

    this.saveCart();
    this.renderCart();
    this.updateCartCount();
  }

  /**
   * Remove item from cart
   * @param {string} itemId - ID of item to remove
   */
  static removeItem(itemId) {
    this.cart = this.cart.filter(item => item.id !== itemId);
    this.saveCart();
    this.renderCart();
    this.updateCartCount();
  }

  /**
   * Update item quantity
   * @param {string} itemId - ID of item to update
   * @param {number} quantity - New quantity
   */
  static updateQuantity(itemId, quantity) {
    if (quantity <= 0) {
      this.removeItem(itemId);
      return;
    }

    const item = this.cart.find(cartItem => cartItem.id === itemId);
    if (item) {
      item.quantity = quantity;
      this.saveCart();
      this.renderCart();
    }
  }

  /**
   * Clear all items from cart
   */
  static clearCart() {
    this.cart = [];
    this.saveCart();
    this.renderCart();
    this.updateCartCount();
  }

  /**
   * Calculate total cart value
   * @returns {number} Total value
   */
  static calculateTotal() {
    return this.cart.reduce((total, item) => {
      const price = this.parsePrice(item.price);
      return total + (price * item.quantity);
    }, 0);
  }

  /**
   * Parse price string to number
   * @private
   * @param {string} priceStr - Price string (e.g., "R$ 1.299,00")
   * @returns {number}
   */
  static parsePrice(priceStr) {
    return parseFloat(priceStr.replace(/[^\d,]/g, '').replace(',', '.')) || 0;
  }

  /**
   * Format price number to string
   * @private
   * @param {number} price - Price number
   * @returns {string}
   */
  static formatPrice(price) {
    return `R$ ${price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
  }

  /**
   * Render cart items in DOM
   * @private
   */
  static renderCart() {
    if (!this.elements.cartItems) return;

    this.elements.cartItems.innerHTML = '';

    if (this.cart.length === 0) {
      this.elements.cartItems.innerHTML = '<p class="empty-cart">Seu carrinho está vazio</p>';
    } else {
      this.cart.forEach((item, index) => {
        const itemElement = this.createCartItemElement(item, index);
        this.elements.cartItems.appendChild(itemElement);
      });
    }

    // Update total
    if (this.elements.cartTotal) {
      const total = this.calculateTotal();
      this.elements.cartTotal.textContent = `Total: ${this.formatPrice(total)}`;
    }
  }

  /**
   * Create cart item DOM element
   * @private
   * @param {Object} item - Cart item
   * @param {number} index - Item index
   * @returns {Element}
   */
  static createCartItemElement(item, index) {
    const itemEl = DOMUtils.createElement('div', { class: 'cart-item' });

    // Product info
    const infoEl = DOMUtils.createElement('div', { class: 'cart-item-info' });

    const nameEl = DOMUtils.createElement('h4', {}, item.name);

    // Quantity controls
    const quantityControls = DOMUtils.createElement('div', { class: 'quantity-controls' });

    const decreaseBtn = DOMUtils.createElement('button', {
      class: 'quantity-btn decrease',
      'data-index': index.toString()
    }, '-');

    const quantityInput = DOMUtils.createElement('input', {
      type: 'number',
      class: 'quantity-input',
      value: item.quantity.toString(),
      min: '1',
      'data-index': index.toString()
    });

    const increaseBtn = DOMUtils.createElement('button', {
      class: 'quantity-btn increase',
      'data-index': index.toString()
    }, '+');

    quantityControls.appendChild(decreaseBtn);
    quantityControls.appendChild(quantityInput);
    quantityControls.appendChild(increaseBtn);

    infoEl.appendChild(nameEl);
    infoEl.appendChild(quantityControls);

    // Price
    const priceEl = DOMUtils.createElement('p', { class: 'cart-item-price' },
      this.formatPrice(this.parsePrice(item.price) * item.quantity));

    // Remove button
    const removeBtn = DOMUtils.createElement('button', {
      class: 'remove-item',
      'data-index': index.toString()
    }, 'Remover');

    // Bind quantity events
    decreaseBtn.addEventListener('click', () => this.updateQuantity(item.id, item.quantity - 1));
    increaseBtn.addEventListener('click', () => this.updateQuantity(item.id, item.quantity + 1));
    quantityInput.addEventListener('change', (e) => {
      const newQuantity = parseInt(e.target.value) || 1;
      this.updateQuantity(item.id, newQuantity);
    });

    // Bind remove event
    removeBtn.addEventListener('click', () => this.removeItem(item.id));

    itemEl.appendChild(infoEl);
    itemEl.appendChild(priceEl);
    itemEl.appendChild(removeBtn);

    return itemEl;
  }

  /**
   * Update cart count badge
   * @private
   */
  static updateCartCount() {
    if (!this.elements.cartCount) return;

    const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);

    if (totalItems > 0) {
      this.elements.cartCount.textContent = totalItems;
      DOMUtils.removeClass(this.elements.cartCount, 'hidden');
    } else {
      DOMUtils.addClass(this.elements.cartCount, 'hidden');
    }
  }

  /**
   * Toggle cart modal visibility
   * @private
   */
  static toggleCart() {
    if (!this.elements.cartModal) return;

    DOMUtils.toggleClass(this.elements.cartModal, 'show');
  }

  /**
   * Handle clicks outside cart modal
   * @private
   * @param {Event} e - Click event
   */
  static handleOutsideClick(e) {
    if (!this.elements.cartModal) return;

    if (!this.elements.cartModal.contains(e.target) &&
        !this.elements.cartIcon.contains(e.target)) {
      DOMUtils.removeClass(this.elements.cartModal, 'show');
    }
  }

  /**
   * Proceed to checkout
   */
  static checkout() {
    if (this.cart.length === 0) {
      alert('Seu carrinho está vazio.');
      return;
    }

    // Save cart before redirecting
    this.saveCart();
    window.location.href = './checkout.html';
  }

  /**
   * Get cart items
   * @returns {Array} Cart items
   */
  static getItems() {
    return [...this.cart];
  }

  /**
   * Get cart item count
   * @returns {number} Total item count
   */
  static getItemCount() {
    return this.cart.reduce((sum, item) => sum + item.quantity, 0);
  }

  /**
   * Check if cart is empty
   * @returns {boolean}
   */
  static isEmpty() {
    return this.cart.length === 0;
  }
}
