/**
 * Modals Component Module
 * Handles modal dialogs for login and product details
 * @module Modals
 */

import { DOMUtils } from '../utils/dom-utils.js';

export class LoginModal {
  /**
   * Initialize login modal
   */
  static init() {
    this.bindEvents();
  }

  /**
   * Bind login modal events
   * @private
   */
  static bindEvents() {
    // Login button click
    const loginBtn = DOMUtils.getElement('.login-btn');
    if (loginBtn) {
      loginBtn.addEventListener('click', this.openModal.bind(this));
    }

    // Close modal events
    const closeBtn = DOMUtils.getElement('.login-modal .close');
    if (closeBtn) {
      closeBtn.addEventListener('click', this.closeModal.bind(this));
    }

    // Click outside to close
    const modal = DOMUtils.getElement('.login-modal');
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          this.closeModal();
        }
      });
    }

    // Form submission
    const loginForm = DOMUtils.getElement('.login-form');
    if (loginForm) {
      loginForm.addEventListener('submit', this.handleLogin.bind(this));
    }

    // Tab switching
    const tabBtns = DOMUtils.getElement('.tab-btn', true);
    DOMUtils.addEventListeners(tabBtns, 'click', this.switchTab.bind(this));
  }

  /**
   * Open login modal
   */
  static openModal() {
    const modal = DOMUtils.getElement('.login-modal');
    if (modal) {
      DOMUtils.addClass(modal, 'show');
      DOMUtils.addClass(document.body, 'modal-open');
    }
  }

  /**
   * Close login modal
   */
  static closeModal() {
    const modal = DOMUtils.getElement('.login-modal');
    if (modal) {
      DOMUtils.removeClass(modal, 'show');
      DOMUtils.removeClass(document.body, 'modal-open');
    }
  }

  /**
   * Handle login form submission
   * @private
   * @param {Event} e - Form submit event
   */
  static handleLogin(e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const email = formData.get('email');
    const password = formData.get('password');

    // Simulate login process
    this.showLoading(true);

    setTimeout(() => {
      this.showLoading(false);

      if (this.validateLogin(email, password)) {
        this.showSuccess('Login realizado com sucesso!');
        setTimeout(() => {
          this.closeModal();
          // Redirect or update UI
        }, 1500);
      } else {
        this.showError('Email ou senha incorretos.');
      }
    }, 1500);
  }

  /**
   * Validate login credentials
   * @private
   * @param {string} email - User email
   * @param {string} password - User password
   * @returns {boolean}
   */
  static validateLogin(email, password) {
    // Simple validation - in real app, this would be server-side
    return email && password && email.includes('@');
  }

  /**
   * Switch between login/register tabs
   * @private
   * @param {Event} e - Click event
   */
  static switchTab(e) {
    const tabBtn = e.currentTarget;
    const tabName = DOMUtils.getAttribute(tabBtn, 'data-tab');

    // Update active tab button
    const tabBtns = DOMUtils.getElement('.tab-btn', true);
    tabBtns.forEach(btn => DOMUtils.removeClass(btn, 'active'));
    DOMUtils.addClass(tabBtn, 'active');

    // Show corresponding tab content
    const tabContents = DOMUtils.getElement('.tab-content', true);
    tabContents.forEach(content => DOMUtils.removeClass(content, 'active'));

    const targetContent = DOMUtils.getElement(`#${tabName}`);
    if (targetContent) {
      DOMUtils.addClass(targetContent, 'active');
    }
  }

  /**
   * Show loading state
   * @private
   * @param {boolean} show - Whether to show loading
   */
  static showLoading(show) {
    const submitBtn = DOMUtils.getElement('.login-submit-btn');
    const originalText = submitBtn ? submitBtn.textContent : '';

    if (show) {
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Entrando...';
        DOMUtils.addClass(submitBtn, 'loading');
      }
    } else {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
        DOMUtils.removeClass(submitBtn, 'loading');
      }
    }
  }

  /**
   * Show success message
   * @private
   * @param {string} message - Success message
   */
  static showSuccess(message) {
    this.showMessage(message, 'success');
  }

  /**
   * Show error message
   * @private
   * @param {string} message - Error message
   */
  static showError(message) {
    this.showMessage(message, 'error');
  }

  /**
   * Show message in modal
   * @private
   * @param {string} message - Message text
   * @param {string} type - Message type ('success' or 'error')
   */
  static showMessage(message, type) {
    const messageEl = DOMUtils.getElement('.login-message');
    if (messageEl) {
      messageEl.textContent = message;
      messageEl.className = `login-message ${type}`;
      DOMUtils.addClass(messageEl, 'show');

      setTimeout(() => {
        DOMUtils.removeClass(messageEl, 'show');
      }, 3000);
    }
  }
}

export class ProductDetailModal {
  /**
   * Current product data
   * @private
   * @type {Object}
   */
  static currentProduct = null;

  /**
   * Initialize product detail modal
   */
  static init() {
    this.bindEvents();
  }

  /**
   * Bind product detail modal events
   * @private
   */
  static bindEvents() {
    // Product card clicks
    const productCards = DOMUtils.getElement('.product-card', true);
    DOMUtils.addEventListeners(productCards, 'click', this.handleProductClick.bind(this));

    // Close modal events
    const closeBtn = DOMUtils.getElement('.product-modal .close');
    if (closeBtn) {
      closeBtn.addEventListener('click', this.closeModal.bind(this));
    }

    // Click outside to close
    const modal = DOMUtils.getElement('.product-modal');
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          this.closeModal();
        }
      });
    }

    // Add to cart button
    const addToCartBtn = DOMUtils.getElement('.product-modal .add-to-cart-btn');
    if (addToCartBtn) {
      addToCartBtn.addEventListener('click', this.addToCart.bind(this));
    }

    // Image zoom functionality
    this.bindImageZoom();
  }

  /**
   * Handle product card clicks
   * @private
   * @param {Event} e - Click event
   */
  static handleProductClick(e) {
    // Don't open modal if clicking on buttons
    if (e.target.closest('.product-button')) {
      return;
    }

    const productCard = e.currentTarget;
    const productId = DOMUtils.getAttribute(productCard, 'data-product-id');

    if (productId) {
      this.loadProductData(productId);
      this.openModal();
    }
  }

  /**
   * Load product data
   * @private
   * @param {string} productId - Product ID
   */
  static loadProductData(productId) {
    // In a real app, this would fetch from an API
    // For now, we'll use mock data
    const mockProducts = {
      'max': {
        id: 'max',
        name: 'AirPure Max',
        price: 'R$ 1.299',
        image: './images/produtos/Max.jpg',
        description: 'O AirPure Max é o purificador premium da linha...',
        specifications: [
          'Filtro HEPA H13 - Remove 99,97% das partículas',
          'Controle via app móvel',
          'Operação ultra silenciosa (<25 dB)',
          'Consumo de energia: 50W',
          'Cobertura: até 50m²'
        ],
        benefits: [
          { icon: '✨', title: 'Design Premium', description: 'Estética minimalista...' },
          { icon: '🏠', title: 'Máximo Conforto', description: 'Operação silenciosa...' }
        ]
      }
      // Add more products...
    };

    this.currentProduct = mockProducts[productId] || null;
    this.renderProductDetails();
  }

  /**
   * Render product details in modal
   * @private
   */
  static renderProductDetails() {
    if (!this.currentProduct) return;

    const modal = DOMUtils.getElement('.product-modal');
    if (!modal) return;

    // Update modal content
    const titleEl = DOMUtils.getElement('.product-modal .product-title');
    const priceEl = DOMUtils.getElement('.product-modal .product-price');
    const imageEl = DOMUtils.getElement('.product-modal .product-image');
    const descEl = DOMUtils.getElement('.product-modal .product-description');

    if (titleEl) titleEl.textContent = this.currentProduct.name;
    if (priceEl) priceEl.textContent = this.currentProduct.price;
    if (imageEl) DOMUtils.setAttribute(imageEl, 'src', this.currentProduct.image);
    if (descEl) descEl.textContent = this.currentProduct.description;

    // Render specifications
    this.renderSpecifications();

    // Render benefits
    this.renderBenefits();
  }

  /**
   * Render product specifications
   * @private
   */
  static renderSpecifications() {
    const specsContainer = DOMUtils.getElement('.product-specifications');
    if (!specsContainer || !this.currentProduct.specifications) return;

    specsContainer.innerHTML = '';

    this.currentProduct.specifications.forEach(spec => {
      const specEl = DOMUtils.createElement('div', { class: 'spec-item' });
      const iconEl = DOMUtils.createElement('span', { class: 'spec-icon' }, '✓');
      const textEl = DOMUtils.createElement('span', { class: 'spec-text' }, spec);

      specEl.appendChild(iconEl);
      specEl.appendChild(textEl);
      specsContainer.appendChild(specEl);
    });
  }

  /**
   * Render product benefits
   * @private
   */
  static renderBenefits() {
    const benefitsContainer = DOMUtils.getElement('.product-benefits');
    if (!benefitsContainer || !this.currentProduct.benefits) return;

    benefitsContainer.innerHTML = '';

    this.currentProduct.benefits.forEach(benefit => {
      const benefitEl = DOMUtils.createElement('div', { class: 'benefit-item' });
      const iconEl = DOMUtils.createElement('div', { class: 'benefit-icon' }, benefit.icon);
      const contentEl = DOMUtils.createElement('div', { class: 'benefit-content' });

      const titleEl = DOMUtils.createElement('h4', {}, benefit.title);
      const descEl = DOMUtils.createElement('p', {}, benefit.description);

      contentEl.appendChild(titleEl);
      contentEl.appendChild(descEl);

      benefitEl.appendChild(iconEl);
      benefitEl.appendChild(contentEl);
      benefitsContainer.appendChild(benefitEl);
    });
  }

  /**
   * Open product detail modal
   */
  static openModal() {
    const modal = DOMUtils.getElement('.product-modal');
    if (modal) {
      DOMUtils.addClass(modal, 'show');
      DOMUtils.addClass(document.body, 'modal-open');
    }
  }

  /**
   * Close product detail modal
   */
  static closeModal() {
    const modal = DOMUtils.getElement('.product-modal');
    if (modal) {
      DOMUtils.removeClass(modal, 'show');
      DOMUtils.removeClass(document.body, 'modal-open');
    }
  }

  /**
   * Add current product to cart
   * @private
   */
  static addToCart() {
    if (!this.currentProduct) return;

    // Import CartManager dynamically to avoid circular dependencies
    import('./cart.js').then(({ CartManager }) => {
      CartManager.addItem(this.currentProduct);
      this.showAddToCartFeedback();
    });
  }

  /**
   * Show add to cart feedback
   * @private
   */
  static showAddToCartFeedback() {
    const feedbackEl = DOMUtils.getElement('.add-to-cart-feedback');
    if (feedbackEl) {
      DOMUtils.addClass(feedbackEl, 'show');
      setTimeout(() => {
        DOMUtils.removeClass(feedbackEl, 'show');
      }, 2000);
    }
  }

  /**
   * Bind image zoom functionality
   * @private
   */
  static bindImageZoom() {
    const productImage = DOMUtils.getElement('.product-modal .product-image');
    if (!productImage) return;

    productImage.addEventListener('click', () => {
      DOMUtils.toggleClass(productImage, 'zoomed');
    });
  }
}
