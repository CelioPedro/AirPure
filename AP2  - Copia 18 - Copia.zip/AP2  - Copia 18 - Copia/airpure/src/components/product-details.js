/**
 * Product Details Component Module
 * Handles product detail page functionality
 * @module ProductDetails
 */

import { DOMUtils } from '../utils/dom-utils.js';

export class ProductDetails {
  /**
   * Product data storage
   * @private
   * @type {Object}
   */
  static productsData = {
    max: {
      name: "AirPure Max",
      price: "R$ 1.299",
      image: "./images/produtos/Max.jpg",
      description: "O AirPure Max é o purificador premium da linha, equipado com filtro HEPA H13 de alta eficiência, capaz de remover 99,97% das partículas de 0,3 mícrons, incluindo vírus, bactérias e alérgenos. Com controle inteligente via app, operação silenciosa e design moderno, ele garante ar puro e saudável para ambientes maiores, como salas de estar ou escritórios.",
      specifications: [
        "Filtro HEPA H13 - Remove 99,97% das partículas",
        "Controle via app móvel",
        "Operação ultra silenciosa (<25 dB)",
        "Consumo de energia: 50W",
        "Cobertura: até 50m²",
        "Dimensões: 30cm x 30cm x 50cm",
        "Peso: 8kg"
      ],
      benefits: [
        {
          icon: "✨",
          title: "Design Premium",
          description: "Estética minimalista que complementa qualquer ambiente moderno."
        },
        {
          icon: "🏠",
          title: "Máximo Conforto",
          description: "Operação silenciosa e eficiente para seu bem-estar diário."
        },
        {
          icon: "💨",
          title: "Ar Puro",
          description: "Eliminação de 99,97% dos poluentes, alérgenos e partículas nocivas."
        },
        {
          icon: "🌱",
          title: "Sustentabilidade",
          description: "Tecnologia eco-friendly com baixo consumo energético."
        }
      ],
      faq: [
        {
          question: "Como funciona o AirPure Max?",
          answer: "O AirPure Max utiliza filtros avançados HEPA H13 para capturar partículas nocivas, com sensores inteligentes que ajustam a purificação conforme a qualidade do ar."
        },
        {
          question: "Qual o tamanho ideal do ambiente?",
          answer: "Ideal para ambientes de até 50m², como salas de estar, quartos grandes ou pequenos escritórios."
        },
        {
          question: "Precisa de manutenção frequente?",
          answer: "Recomendamos limpeza mensal dos filtros externos e substituição do filtro HEPA a cada 6-12 meses, dependendo do uso."
        },
        {
          question: "É compatível com app?",
          answer: "Sim, possui controle total via aplicativo móvel para iOS e Android, permitindo ajustes remotos e monitoramento em tempo real."
        }
      ]
    },
    compact: {
      name: "AirPure Compact",
      price: "R$ 799",
      image: "./images/produtos/Compact.jpg",
      description: "O AirPure Compact é a solução perfeita para espaços menores. Com design compacto e eficiente, oferece purificação de ar de alta qualidade com baixo consumo energético.",
      specifications: [
        "Filtro HEPA H12 - Remove 99,5% das partículas",
        "Design compacto e moderno",
        "Operação silenciosa (<20 dB)",
        "Consumo de energia: 25W",
        "Cobertura: até 20m²",
        "Dimensões: 20cm x 20cm x 30cm",
        "Peso: 3kg"
      ],
      benefits: [
        {
          icon: "📏",
          title: "Tamanho Compacto",
          description: "Ideal para quartos, home offices e espaços reduzidos."
        },
        {
          icon: "🔋",
          title: "Baixo Consumo",
          description: "Tecnologia eficiente que economiza energia."
        },
        {
          icon: "🎨",
          title: "Design Moderno",
          description: "Integra-se perfeitamente à decoração contemporânea."
        }
      ],
      faq: [
        {
          question: "Para quais ambientes é indicado?",
          answer: "Perfeito para quartos, salas pequenas, home offices e ambientes de até 20m²."
        },
        {
          question: "Faz barulho durante o uso?",
          answer: "Opera em modo ultra-silencioso, ideal para uso noturno e ambientes de trabalho."
        }
      ]
    },
    silent: {
      name: "AirPure Silent",
      price: "R$ 999",
      image: "./images/produtos/Silent.jpg",
      description: "O AirPure Silent combina eficiência máxima com operação praticamente inaudível. Perfeito para quartos, bibliotecas e ambientes que exigem silêncio absoluto.",
      specifications: [
        "Filtro HEPA H13 - Remove 99,97% das partículas",
        "Operação ultra silenciosa (<15 dB)",
        "Controle via app móvel",
        "Consumo de energia: 35W",
        "Cobertura: até 35m²",
        "Dimensões: 25cm x 25cm x 40cm",
        "Peso: 5kg"
      ],
      benefits: [
        {
          icon: "🤫",
          title: "Ultra Silencioso",
          description: "Operação praticamente inaudível, ideal para ambientes tranquilos."
        },
        {
          icon: "📱",
          title: "Controle Inteligente",
          description: "Gerencie via aplicativo com agendamento automático."
        }
      ],
      faq: [
        {
          question: "É realmente silencioso?",
          answer: "Sim, opera com menos de 15dB, mais silencioso que um sussurro, perfeito para quartos e bibliotecas."
        }
      ]
    }
  };

  /**
   * Initialize product details functionality
   */
  static init() {
    this.bindEvents();
    this.renderProductDetails();
    this.initFeaturesAccordion();
  }

  /**
   * Bind product details events
   * @private
   */
  static bindEvents() {
    // Image zoom functionality
    const productImage = DOMUtils.getElement('.product-image');
    if (productImage) {
      productImage.addEventListener('click', (e) => this.handleImageZoom(e, productImage));
      productImage.addEventListener('mousemove', (e) => this.handleZoomMove(e, productImage));
      productImage.addEventListener('mouseleave', () => this.handleZoomOut(productImage));
    }

    // Add to cart button
    const addToCartBtn = DOMUtils.getElement('.add-to-cart-btn');
    if (addToCartBtn) {
      addToCartBtn.addEventListener('click', this.handleAddToCart.bind(this));
    }

    // Quantity controls
    this.bindQuantityControls();

    // Specification tabs
    this.bindSpecificationTabs();
  }

  /**
   * Render product details based on URL parameter
   * @private
   */
  static renderProductDetails() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('product') || 'max';

    const product = this.productsData[productId];
    if (!product) {
      console.warn(`Product ${productId} not found`);
      return;
    }

    this.updateProductInfo(product);
    this.renderSpecifications(product);
    this.renderBenefits(product);
    this.renderFAQ(product);
  }

  /**
   * Update product information in DOM
   * @private
   * @param {Object} product - Product data
   */
  static updateProductInfo(product) {
    const elements = {
      title: DOMUtils.getElement('.product-title'),
      price: DOMUtils.getElement('.product-price'),
      image: DOMUtils.getElement('.product-image'),
      description: DOMUtils.getElement('.product-description')
    };

    if (elements.title) elements.title.textContent = product.name;
    if (elements.price) elements.price.textContent = product.price;
    if (elements.image) DOMUtils.setAttribute(elements.image, 'src', product.image);
    if (elements.description) elements.description.textContent = product.description;
  }

  /**
   * Render product specifications
   * @private
   * @param {Object} product - Product data
   */
  static renderSpecifications(product) {
    const specsContainer = DOMUtils.getElement('.product-specifications');
    if (!specsContainer || !product.specifications) return;

    specsContainer.innerHTML = '';

    product.specifications.forEach(spec => {
      const specItem = DOMUtils.createElement('div', { class: 'spec-item' });

      const icon = DOMUtils.createElement('span', { class: 'spec-icon' }, '✓');
      const text = DOMUtils.createElement('span', { class: 'spec-text' }, spec);

      specItem.appendChild(icon);
      specItem.appendChild(text);
      specsContainer.appendChild(specItem);
    });
  }

  /**
   * Render product benefits
   * @private
   * @param {Object} product - Product data
   */
  static renderBenefits(product) {
    const benefitsContainer = DOMUtils.getElement('.product-benefits');
    if (!benefitsContainer || !product.benefits) return;

    benefitsContainer.innerHTML = '';

    product.benefits.forEach(benefit => {
      const benefitEl = DOMUtils.createElement('div', { class: 'benefit-item' });

      const icon = DOMUtils.createElement('div', { class: 'benefit-icon' }, benefit.icon);
      const content = DOMUtils.createElement('div', { class: 'benefit-content' });

      const title = DOMUtils.createElement('h4', {}, benefit.title);
      const description = DOMUtils.createElement('p', {}, benefit.description);

      content.appendChild(title);
      content.appendChild(description);

      benefitEl.appendChild(icon);
      benefitEl.appendChild(content);
      benefitsContainer.appendChild(benefitEl);
    });
  }

  /**
   * Render product FAQ
   * @private
   * @param {Object} product - Product data
   */
  static renderFAQ(product) {
    const faqContainer = DOMUtils.getElement('.product-faq');
    if (!faqContainer || !product.faq) return;

    faqContainer.innerHTML = '';

    product.faq.forEach((item, index) => {
      const faqItem = DOMUtils.createElement('div', { class: 'faq-item' });

      const question = DOMUtils.createElement('button', {
        class: 'faq-question',
        'aria-expanded': 'false',
        'aria-controls': `faq-answer-${index}`
      }, item.question);

      const answer = DOMUtils.createElement('div', {
        class: 'faq-answer',
        id: `faq-answer-${index}`
      });

      const answerP = DOMUtils.createElement('p', {}, item.answer);
      answer.appendChild(answerP);

      faqItem.appendChild(question);
      faqItem.appendChild(answer);
      faqContainer.appendChild(faqItem);

      // Bind click event
      question.addEventListener('click', () => this.toggleFAQItem(faqItem));
    });
  }

  /**
   * Toggle FAQ item
   * @private
   * @param {Element} faqItem - FAQ item element
   */
  static toggleFAQItem(faqItem) {
    const question = DOMUtils.getElement('.faq-question', false, faqItem);
    const answer = DOMUtils.getElement('.faq-answer', false, faqItem);

    if (!question || !answer) return;

    const isExpanded = DOMUtils.getAttribute(question, 'aria-expanded') === 'true';

    if (isExpanded) {
      this.closeFAQItem(faqItem);
    } else {
      this.openFAQItem(faqItem);
    }
  }

  /**
   * Open FAQ item
   * @private
   * @param {Element} faqItem - FAQ item element
   */
  static openFAQItem(faqItem) {
    const question = DOMUtils.getElement('.faq-question', false, faqItem);
    const answer = DOMUtils.getElement('.faq-answer', false, faqItem);

    if (!question || !answer) return;

    DOMUtils.setAttribute(question, 'aria-expanded', 'true');
    DOMUtils.addClass(faqItem, 'active');

    const scrollHeight = answer.scrollHeight;
    answer.style.maxHeight = scrollHeight + 'px';
  }

  /**
   * Close FAQ item
   * @private
   * @param {Element} faqItem - FAQ item element
   */
  static closeFAQItem(faqItem) {
    const question = DOMUtils.getElement('.faq-question', false, faqItem);
    const answer = DOMUtils.getElement('.faq-answer', false, faqItem);

    if (!question || !answer) return;

    DOMUtils.setAttribute(question, 'aria-expanded', 'false');
    DOMUtils.removeClass(faqItem, 'active');
    answer.style.maxHeight = '0px';
  }

  /**
   * Handle image zoom functionality
   * @private
   * @param {Event} e - Click event
   * @param {Element} img - Image element
   */
  static handleImageZoom(e, img) {
    const isZoomed = DOMUtils.hasClass(img, 'zoomed');

    if (isZoomed) {
      this.handleZoomOut(img);
    } else {
      this.handleZoomIn(e, img);
    }
  }

  /**
   * Zoom in on image
   * @private
   * @param {Event} e - Click event
   * @param {Element} img - Image element
   */
  static handleZoomIn(e, img) {
    const imgRect = img.getBoundingClientRect();
    const x = e.clientX - imgRect.left;
    const y = e.clientY - imgRect.top;

    const xPercent = (x / imgRect.width) * 100;
    const yPercent = (y / imgRect.height) * 100;

    Object.assign(img.style, {
      transition: 'transform 0.1s ease',
      transform: 'scale(2)',
      transformOrigin: `${xPercent}% ${yPercent}%`,
      cursor: 'zoom-out'
    });

    DOMUtils.addClass(img, 'zoomed');
  }

  /**
   * Zoom out from image
   * @private
   * @param {Element} img - Image element
   */
  static handleZoomOut(img) {
    Object.assign(img.style, {
      transform: 'scale(1)',
      transformOrigin: 'center center',
      cursor: 'zoom-in'
    });

    DOMUtils.removeClass(img, 'zoomed');
  }

  /**
   * Handle zoom move on image
   * @private
   * @param {Event} e - Mouse move event
   * @param {Element} img - Image element
   */
  static handleZoomMove(e, img) {
    if (!DOMUtils.hasClass(img, 'zoomed')) return;

    const imgRect = img.getBoundingClientRect();
    const x = e.clientX - imgRect.left;
    const y = e.clientY - imgRect.top;

    const xPercent = (x / imgRect.width) * 100;
    const yPercent = (y / imgRect.height) * 100;

    img.style.transformOrigin = `${xPercent}% ${yPercent}%`;
  }

  /**
   * Bind quantity controls
   * @private
   */
  static bindQuantityControls() {
    const decreaseBtn = DOMUtils.getElement('.quantity-decrease');
    const increaseBtn = DOMUtils.getElement('.quantity-increase');
    const quantityInput = DOMUtils.getElement('.quantity-input');

    if (decreaseBtn) {
      decreaseBtn.addEventListener('click', () => this.updateQuantity(-1));
    }

    if (increaseBtn) {
      increaseBtn.addEventListener('click', () => this.updateQuantity(1));
    }

    if (quantityInput) {
      quantityInput.addEventListener('change', (e) => {
        const newQuantity = parseInt(e.target.value) || 1;
        this.setQuantity(newQuantity);
      });
    }
  }

  /**
   * Update quantity
   * @private
   * @param {number} change - Quantity change (+1 or -1)
   */
  static updateQuantity(change) {
    const quantityInput = DOMUtils.getElement('.quantity-input');
    if (!quantityInput) return;

    const currentQuantity = parseInt(quantityInput.value) || 1;
    const newQuantity = Math.max(1, currentQuantity + change);

    quantityInput.value = newQuantity;
    this.updatePrice(newQuantity);
  }

  /**
   * Set quantity directly
   * @private
   * @param {number} quantity - New quantity
   */
  static setQuantity(quantity) {
    const quantityInput = DOMUtils.getElement('.quantity-input');
    if (!quantityInput) return;

    const newQuantity = Math.max(1, quantity);
    quantityInput.value = newQuantity;
    this.updatePrice(newQuantity);
  }

  /**
   * Update price based on quantity
   * @private
   * @param {number} quantity - Current quantity
   */
  static updatePrice(quantity) {
    const priceElement = DOMUtils.getElement('.product-price');
    if (!priceElement) return;

    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('product') || 'max';
    const product = this.productsData[productId];

    if (product) {
      const basePrice = this.parsePrice(product.price);
      const totalPrice = basePrice * quantity;
      priceElement.textContent = this.formatPrice(totalPrice);
    }
  }

  /**
   * Parse price string to number
   * @private
   * @param {string} priceStr - Price string
   * @returns {number}
   */
  static parsePrice(priceStr) {
    return parseFloat(priceStr.replace(/[^\d,]/g, '').replace(',', '.')) || 0;
  }

  /**
   * Format price number to string
   * @private
   * @param {number} price - Price number
   * @returns {string}
   */
  static formatPrice(price) {
    return `R$ ${price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
  }

  /**
   * Handle add to cart
   * @private
   */
  static handleAddToCart() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('product') || 'max';
    const quantityInput = DOMUtils.getElement('.quantity-input');
    const quantity = parseInt(quantityInput?.value) || 1;

    const product = this.productsData[productId];
    if (!product) return;

    // Import CartManager dynamically
    import('./cart.js').then(({ CartManager }) => {
      CartManager.addItem({
        ...product,
        quantity: quantity,
        id: productId
      });

      this.showAddToCartFeedback();
    });
  }

  /**
   * Show add to cart feedback
   * @private
   */
  static showAddToCartFeedback() {
    const feedbackEl = DOMUtils.getElement('.add-to-cart-feedback');
    if (feedbackEl) {
      DOMUtils.addClass(feedbackEl, 'show');
      setTimeout(() => {
        DOMUtils.removeClass(feedbackEl, 'show');
      }, 2000);
    }
  }

  /**
   * Bind specification tabs
   * @private
   */
  static bindSpecificationTabs() {
    const tabBtns = DOMUtils.getElement('.spec-tab-btn', true);
    DOMUtils.addEventListeners(tabBtns, 'click', this.handleTabSwitch.bind(this));
  }

  /**
   * Handle tab switching
   * @private
   * @param {Event} e - Click event
   */
  static handleTabSwitch(e) {
    const tabBtn = e.currentTarget;
    const tabName = DOMUtils.getAttribute(tabBtn, 'data-tab');

    // Update active tab
    const tabBtns = DOMUtils.getElement('.spec-tab-btn', true);
    tabBtns.forEach(btn => DOMUtils.removeClass(btn, 'active'));
    DOMUtils.addClass(tabBtn, 'active');

    // Show corresponding content
    const tabContents = DOMUtils.getElement('.spec-tab-content', true);
    tabContents.forEach(content => DOMUtils.removeClass(content, 'active'));

    const targetContent = DOMUtils.getElement(`#${tabName}`);
    if (targetContent) {
      DOMUtils.addClass(targetContent, 'active');
    }
  }

  /**
   * Initialize features accordion
   * @private
   */
  static initFeaturesAccordion() {
    const featuresContainer = DOMUtils.getElement('.product-features');
    if (!featuresContainer) return;

    const features = [
      "Filtro HEPA H13 de alta eficiência",
      "Controle via app móvel",
      "Operação ultra silenciosa",
      "Indicador de troca de filtro",
      "Design compacto e moderno"
    ];

    features.forEach((feature, index) => {
      const item = DOMUtils.createElement('div', { class: 'faq-item' });

      const button = DOMUtils.createElement('button', {
        class: 'faq-question',
        'aria-expanded': 'false',
        'aria-controls': `feature-content-${index}`
      }, feature);

      const content = DOMUtils.createElement('div', {
        class: 'faq-answer',
        id: `feature-content-${index}`
      });

      const p = DOMUtils.createElement('p', {}, "Detalhes adicionais sobre esta característica.");

      content.appendChild(p);
      item.appendChild(button);
      item.appendChild(content);
      featuresContainer.appendChild(item);

      button.addEventListener('click', () => this.toggleFAQItem(item));
    });
  }

  /**
   * Get product data by ID
   * @param {string} productId - Product ID
   * @returns {Object|null}
   */
  static getProduct(productId) {
    return this.productsData[productId] || null;
  }

  /**
   * Get all products
   * @returns {Object}
   */
  static getAllProducts() {
    return this.productsData;
  }
}
