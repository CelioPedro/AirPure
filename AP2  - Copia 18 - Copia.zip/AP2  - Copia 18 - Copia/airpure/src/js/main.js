import '../styles/main.scss';

/**
 * AirPure Application Main Entry Point
 * Initializes all modules and components
 * @module Main
 */

import { NavigationManager } from '../components/navigation.js';
import { AnimationManager } from '../components/animations.js';
import { ProductManager } from '../components/products.js';
import { CartManager } from '../components/cart.js';
import { LoginModal, ProductDetailModal } from '../components/modals.js';
import { FAQManager } from '../components/faq.js';
import { HeroSlider } from '../components/hero-slider.js';
import { ProductDetails } from '../components/product-details.js';

/**
 * Initialize the application
 */
function initApp() {
  console.log('🚀 Initializing AirPure application...');

  // Initialize core components
  NavigationManager.init();
  AnimationManager.init();
  ProductManager.init();
  CartManager.init();
  LoginModal.init();
  ProductDetailModal.init();
  FAQManager.init();
  HeroSlider.init();
  ProductDetails.init();

  console.log('✅ AirPure application initialized successfully');
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', initApp);

// Export for debugging (optional)
if (typeof window !== 'undefined') {
  window.AirPure = {
    NavigationManager,
    AnimationManager,
    ProductManager,
    CartManager,
    LoginModal,
    ProductDetailModal,
    FAQManager,
    HeroSlider,
    ProductDetails
  };
}
