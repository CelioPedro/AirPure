/**
 * Checkout Page JavaScript
 * Handles form validation, cart display, and order processing
 */

class CheckoutManager {
  constructor() {
    this.cart = [];
    this.form = document.getElementById('checkoutForm');
    this.cartItemsContainer = document.getElementById('cart-items');
    this.totalPriceElement = document.getElementById('total-price');
    this.checkoutButton = document.querySelector('.checkout-button');
    this.successMessage = document.querySelector('.success-message');

    this.init();
  }

  init() {
    this.loadCart();
    this.displayCart();
    this.setupFormValidation();
    this.setupPaymentMethodToggle();
    this.setupFormSubmission();
  }

  loadCart() {
    // Load cart from localStorage or use window.cartManager if available
    if (window.cartManager && window.cartManager.cart) {
      this.cart = window.cartManager.cart;
    } else {
      const savedCart = localStorage.getItem('airpure-cart');
      this.cart = savedCart ? JSON.parse(savedCart) : [];
    }
  }

  displayCart() {
    if (this.cart.length === 0) {
      this.cartItemsContainer.innerHTML = '<p>Seu carrinho está vazio.</p>';
      this.totalPriceElement.textContent = 'R$ 0,00';
      this.checkoutButton.disabled = true;
      return;
    }

    this.cartItemsContainer.innerHTML = '';
    let total = 0;

    this.cart.forEach((item, index) => {
      const itemTotal = this.parsePrice(item.price) * item.quantity;
      total += itemTotal;

      const itemElement = document.createElement('div');
      itemElement.className = 'cart-item';
      itemElement.innerHTML = `
        <div class="cart-item-info">
          <div class="cart-item-name">${item.name}</div>
          <div class="cart-item-price">${item.price}</div>
          <div class="cart-item-quantity">Quantidade: ${item.quantity}</div>
        </div>
        <div class="cart-item-total">R$ ${itemTotal.toFixed(2).replace('.', ',')}</div>
      `;

      this.cartItemsContainer.appendChild(itemElement);
    });

    this.totalPriceElement.textContent = `R$ ${total.toFixed(2).replace('.', ',')}`;
  }

  parsePrice(priceString) {
    return parseFloat(priceString.replace(/[^\d,]/g, '').replace(',', '.')) || 0;
  }

  setupFormValidation() {
    const inputs = this.form.querySelectorAll('input[required], select[required]');

    inputs.forEach(input => {
      input.addEventListener('blur', () => this.validateField(input));
      input.addEventListener('input', () => this.clearFieldError(input));
    });
  }

  validateField(field) {
    const formGroup = field.closest('.form-group');
    const errorMessage = formGroup.querySelector('.error-message') || this.createErrorMessage(formGroup);

    let isValid = true;
    let message = '';

    switch (field.name) {
      case 'email':
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(field.value)) {
          isValid = false;
          message = 'Por favor, insira um e-mail válido.';
        }
        break;
      case 'phone':
        const phoneRegex = /^\(\d{2}\)\s\d{4,5}-\d{4}$/;
        if (!phoneRegex.test(field.value)) {
          isValid = false;
          message = 'Por favor, insira um telefone válido (ex: (11) 99999-9999).';
        }
        break;
      case 'zipCode':
        const zipRegex = /^\d{5}-\d{3}$/;
        if (!zipRegex.test(field.value)) {
          isValid = false;
          message = 'Por favor, insira um CEP válido (ex: 12345-678).';
        }
        break;
      case 'cardNumber':
        if (field.value.replace(/\s/g, '').length < 16) {
          isValid = false;
          message = 'Número do cartão deve ter pelo menos 16 dígitos.';
        }
        break;
      case 'expiryDate':
        const expiryRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
        if (!expiryRegex.test(field.value)) {
          isValid = false;
          message = 'Data deve estar no formato MM/AA.';
        }
        break;
      case 'cvv':
        if (field.value.length < 3) {
          isValid = false;
          message = 'CVV deve ter pelo menos 3 dígitos.';
        }
        break;
      default:
        if (!field.value.trim()) {
          isValid = false;
          message = 'Este campo é obrigatório.';
        }
    }

    if (!isValid) {
      formGroup.classList.add('error');
      errorMessage.textContent = message;
    } else {
      formGroup.classList.remove('error');
      errorMessage.textContent = '';
    }

    return isValid;
  }

  createErrorMessage(formGroup) {
    const errorMessage = document.createElement('div');
    errorMessage.className = 'error-message';
    formGroup.appendChild(errorMessage);
    return errorMessage;
  }

  clearFieldError(field) {
    const formGroup = field.closest('.form-group');
    formGroup.classList.remove('error');
    const errorMessage = formGroup.querySelector('.error-message');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  setupPaymentMethodToggle() {
    const paymentMethods = document.querySelectorAll('input[name="paymentMethod"]');
    const creditCardFields = document.getElementById('creditCardFields');

    paymentMethods.forEach(method => {
      method.addEventListener('change', () => {
        if (method.value === 'credit' || method.value === 'debit') {
          creditCardFields.style.display = 'block';
          // Make card fields required
          creditCardFields.querySelectorAll('input').forEach(input => {
            input.required = true;
          });
        } else {
          creditCardFields.style.display = 'none';
          // Remove required from card fields
          creditCardFields.querySelectorAll('input').forEach(input => {
            input.required = false;
            input.value = '';
            this.clearFieldError(input);
          });
        }
      });
    });
  }

  setupFormSubmission() {
    this.form.addEventListener('submit', (e) => {
      e.preventDefault();

      if (this.validateForm()) {
        this.processOrder();
      }
    });
  }

  validateForm() {
    const requiredFields = this.form.querySelectorAll('input[required], select[required]');
    let isValid = true;

    requiredFields.forEach(field => {
      if (!this.validateField(field)) {
        isValid = false;
      }
    });

    return isValid;
  }

  processOrder() {
    // Show loading state
    this.checkoutButton.classList.add('loading');
    this.checkoutButton.textContent = 'Processando...';
    this.checkoutButton.disabled = true;

    // Simulate processing delay
    setTimeout(() => {
      // Clear cart
      this.cart = [];
      localStorage.removeItem('airpure-cart');
      if (window.cartManager) {
        window.cartManager.cart = [];
        window.cartManager.renderCart();
      }

      // Show success message
      this.showSuccessMessage();

      // Reset form
      this.form.reset();

      // Reset button
      this.checkoutButton.classList.remove('loading');
      this.checkoutButton.textContent = 'Finalizar Compra';
      this.checkoutButton.disabled = false;

      // Update cart display
      this.displayCart();
    }, 2000);
  }

  showSuccessMessage() {
    if (!this.successMessage) {
      this.successMessage = document.createElement('div');
      this.successMessage.className = 'success-message';
      this.successMessage.innerHTML = `
        <h3>Pedido realizado com sucesso!</h3>
        <p>Obrigado por sua compra. Você receberá um e-mail de confirmação em breve.</p>
      `;
      this.form.appendChild(this.successMessage);
    }

    this.successMessage.classList.add('show');

    // Hide after 5 seconds
    setTimeout(() => {
      this.successMessage.classList.remove('show');
    }, 5000);
  }
}

// Format phone input
function formatPhone(input) {
  let value = input.value.replace(/\D/g, '');
  if (value.length <= 11) {
    value = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    value = value.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
  }
  input.value = value;
}

// Format CEP input
function formatCEP(input) {
  let value = input.value.replace(/\D/g, '');
  if (value.length <= 8) {
    value = value.replace(/(\d{5})(\d{3})/, '$1-$2');
  }
  input.value = value;
}

// Format card number input
function formatCardNumber(input) {
  let value = input.value.replace(/\D/g, '');
  value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
  input.value = value;
}

// Format expiry date input
function formatExpiryDate(input) {
  let value = input.value.replace(/\D/g, '');
  if (value.length >= 2) {
    value = value.replace(/(\d{2})(\d{2})/, '$1/$2');
  }
  input.value = value;
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  new CheckoutManager();

  // Setup input formatters
  const phoneInput = document.getElementById('phone');
  const zipInput = document.getElementById('zipCode');
  const cardNumberInput = document.getElementById('cardNumber');
  const expiryInput = document.getElementById('expiryDate');

  if (phoneInput) {
    phoneInput.addEventListener('input', () => formatPhone(phoneInput));
  }

  if (zipInput) {
    zipInput.addEventListener('input', () => formatCEP(zipInput));
  }

  if (cardNumberInput) {
    cardNumberInput.addEventListener('input', () => formatCardNumber(cardNumberInput));
  }

  if (expiryInput) {
    expiryInput.addEventListener('input', () => formatExpiryDate(expiryInput));
  }
});
