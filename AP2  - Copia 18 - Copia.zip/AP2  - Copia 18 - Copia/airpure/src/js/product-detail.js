// Product Detail Page JavaScript
// Holds product data in variables for reusability

// Product Data Variables for all products
const productsData = {
  max: {
    name: "AirPure Max",
    price: "R$ 1.299",
    image: "./images/produtos/Max.jpg",
    description: "O AirPure Max é o purificador premium da linha, equipado com filtro HEPA H13 de alta eficiência, capaz de remover 99,97% das partículas de 0,3 mícrons, incluindo vírus, bactérias e alérgenos. Com controle inteligente via app, operação silenciosa e design moderno, ele garante ar puro e saudável para ambientes maiores, como salas de estar ou escritórios.",
    specifications: [
      "Filtro HEPA H13 - Remove 99,97% das partículas",
      "Controle via app móvel",
      "Operação ultra silenciosa (<25 dB)",
      "Consumo de energia: 50W",
      "Cobertura: até 50m²",
      "Dimensões: 30cm x 30cm x 50cm",
      "Peso: 8kg"
    ],
    benefits: [
      {
        icon: "✨",
        title: "Design Premium",
        description: "Estética minimalista que complementa qualquer ambiente moderno."
      },
      {
        icon: "🏠",
        title: "Máximo Conforto",
        description: "Operação silenciosa e eficiente para seu bem-estar diário."
      },
      {
        icon: "💨",
        title: "Ar Puro",
        description: "Eliminação de 99,97% dos poluentes, alérgenos e partículas nocivas."
      },
      {
        icon: "🌱",
        title: "Sustentabilidade",
        description: "Tecnologia eco-friendly com baixo consumo energético."
      }
    ],
    faq: [
      {
        question: "Como funciona o AirPure Max?",
        answer: "O AirPure Max utiliza filtros avançados HEPA H13 para capturar partículas nocivas, com sensores inteligentes que ajustam a purificação conforme a qualidade do ar."
      },
      {
        question: "Qual o tamanho ideal do ambiente?",
        answer: "Ideal para ambientes de até 50m², como salas de estar, quartos grandes ou pequenos escritórios."
      },
      {
        question: "Precisa de manutenção frequente?",
        answer: "Recomendamos limpeza mensal dos filtros externos e substituição do filtro HEPA a cada 6-12 meses, dependendo do uso."
      },
      {
        question: "É compatível com app?",
        answer: "Sim, possui controle total via aplicativo móvel para iOS e Android, permitindo ajustes remotos e monitoramento em tempo real."
      }
    ]
  },
  compact: {
    name: "AirPure Compact",
    price: "R$ 599",
    image: "./images/produtos/Compact.jpg",
    description: "O AirPure Compact é perfeito para espaços menores, como quartos pequenos ou mesas de trabalho. Seu design compacto e portátil permite fácil movimentação, enquanto o filtro HEPA H11 garante remoção eficiente de alérgenos e partículas nocivas, proporcionando ar puro onde você precisar.",
    specifications: [
      "Filtro HEPA H11 - Remove 99,97% das partículas",
      "Design compacto e portátil",
      "Operação silenciosa (<25 dB)",
      "Consumo de energia: 25W",
      "Cobertura: até 20m²",
      "Dimensões: 20cm x 20cm x 30cm",
      "Peso: 3kg"
    ],
    benefits: [
      {
        icon: "📦",
        title: "Compacto",
        description: "Design pequeno ideal para espaços reduzidos."
      },
      {
        icon: "🚀",
        title: "Portátil",
        description: "Fácil de mover e transportar."
      },
      {
        icon: "💨",
        title: "Purificação Eficiente",
        description: "Filtro HEPA H11 para remoção de alérgenos."
      },
      {
        icon: "🔇",
        title: "Silencioso",
        description: "Operação discreta sem perturbar."
      }
    ],
    faq: [
      {
        question: "Como funciona o AirPure Compact?",
        answer: "O AirPure Compact utiliza filtro HEPA H11 para capturar partículas nocivas, ideal para espaços menores."
      },
      {
        question: "Qual o tamanho ideal do ambiente?",
        answer: "Ideal para ambientes de até 20m², como quartos pequenos ou mesas de trabalho."
      },
      {
        question: "Precisa de manutenção frequente?",
        answer: "Recomendamos limpeza mensal dos filtros externos e substituição do filtro HEPA a cada 6-12 meses."
      },
      {
        question: "É compatível com app?",
        answer: "Não possui controle via app, mas tem controles manuais simples."
      }
    ]
  },
  mini: {
    name: "AirPure Mini",
    price: "R$ 399",
    image: "./images/produtos/Mini.jpg",
    description: "O AirPure Mini é o purificador compacto e silencioso, ideal para mesa de trabalho. Com filtro HEPA H13 e carvão ativado, oferece purificação eficiente em espaços menores.",
    specifications: [
      "Filtro HEPA H13 - Remove 99,97% das partículas",
      "Filtro de carvão ativado",
      "Operação ultra silenciosa (<25 dB)",
      "Consumo de energia: 15W",
      "Cobertura: até 20m²",
      "Dimensões: 15cm x 15cm x 25cm",
      "Peso: 2kg"
    ],
    benefits: [
      {
        icon: "🪑",
        title: "Para Mesa",
        description: "Tamanho ideal para mesa de trabalho."
      },
      {
        icon: "🔇",
        title: "Ultra Silencioso",
        description: "Operação praticamente inaudível."
      },
      {
        icon: "💨",
        title: "Purificação Avançada",
        description: "Filtro HEPA H13 e carvão ativado."
      },
      {
        icon: "⚡",
        title: "Baixo Consumo",
        description: "Economia de energia com 15W."
      }
    ],
    faq: [
      {
        question: "Como funciona o AirPure Mini?",
        answer: "O AirPure Mini utiliza filtro HEPA H13 e carvão ativado para purificação eficiente em espaços pequenos."
      },
      {
        question: "Qual o tamanho ideal do ambiente?",
        answer: "Ideal para ambientes de até 20m², como mesas de trabalho ou pequenos quartos."
      },
      {
        question: "Precisa de manutenção frequente?",
        answer: "Recomendamos limpeza mensal e substituição dos filtros a cada 6-12 meses."
      },
      {
        question: "É compatível com app?",
        answer: "Não possui controle via app, mas tem controles manuais simples."
      }
    ]
  },
  silent: {
    name: "AirPure Silent",
    price: "R$ 899",
    image: "./images/produtos/Silent.jpg",
    description: "O AirPure Silent é projetado para operação ultra silenciosa, ideal para quartos, escritórios e ambientes que exigem tranquilidade. Equipado com filtro HEPA H12, remove eficientemente alérgenos, poeira e partículas nocivas, garantindo ar puro sem perturbar o silêncio.",
    specifications: [
      "Filtro HEPA H12 - Remove 99,97% das partículas",
      "Operação ultra silenciosa (<20 dB)",
      "Consumo de energia: 30W",
      "Cobertura: até 30m²",
      "Dimensões: 25cm x 25cm x 40cm",
      "Peso: 5kg"
    ],
    benefits: [
      {
        icon: "🔇",
        title: "Ultra Silencioso",
        description: "Operação com menos de 20 dB."
      },
      {
        icon: "🏠",
        title: "Para Ambientes Tranquilos",
        description: "Ideal para quartos e escritórios."
      },
      {
        icon: "💨",
        title: "Purificação Eficiente",
        description: "Filtro HEPA H12 para remoção de partículas."
      },
      {
        icon: "🌙",
        title: "Modo Noturno",
        description: "Operação discreta durante a noite."
      }
    ],
    faq: [
      {
        question: "Como funciona o AirPure Silent?",
        answer: "O AirPure Silent utiliza filtro HEPA H12 com operação ultra silenciosa para purificação discreta."
      },
      {
        question: "Qual o tamanho ideal do ambiente?",
        answer: "Ideal para ambientes de até 30m², como quartos ou pequenos escritórios."
      },
      {
        question: "Precisa de manutenção frequente?",
        answer: "Recomendamos limpeza mensal e substituição do filtro HEPA a cada 6-12 meses."
      },
      {
        question: "É compatível com app?",
        answer: "Possui controle básico via app para ajustes simples."
      }
    ]
  },
  zen: {
    name: "AirPure Zen",
    price: "R$ 1.199",
    image: "./images/produtos/Zen.jpg",
    description: "O AirPure Zen combina purificação premium com aromaterapia integrada, criando um ambiente relaxante e saudável. Equipado com filtro HEPA H13 e operação ultra silenciosa, é ideal para quartos e espaços de bem-estar, proporcionando ar puro com toques aromáticos personalizáveis.",
    specifications: [
      "Filtro HEPA H13 - Remove 99,97% das partículas",
      "Aromaterapia integrada",
      "Operação ultra silenciosa (<22 dB)",
      "Consumo de energia: 35W",
      "Cobertura: até 40m²",
      "Dimensões: 28cm x 28cm x 45cm",
      "Peso: 6kg"
    ],
    benefits: [
      {
        icon: "🌸",
        title: "Aromaterapia",
        description: "Difusão de óleos essenciais para relaxamento."
      },
      {
        icon: "🔇",
        title: "Ultra Silencioso",
        description: "Operação com menos de 22 dB."
      },
      {
        icon: "💨",
        title: "Purificação Premium",
        description: "Filtro HEPA H13 para máxima eficiência."
      },
      {
        icon: "🧘",
        title: "Bem-Estar",
        description: "Ambiente relaxante e saudável."
      }
    ],
    faq: [
      {
        question: "Como funciona o AirPure Zen?",
        answer: "O AirPure Zen combina purificação HEPA H13 com aromaterapia integrada para ar puro e relaxante."
      },
      {
        question: "Qual o tamanho ideal do ambiente?",
        answer: "Ideal para ambientes de até 40m², como quartos ou espaços de bem-estar."
      },
      {
        question: "Precisa de manutenção frequente?",
        answer: "Recomendamos limpeza mensal, substituição do filtro HEPA a cada 6-12 meses e recarga de óleos essenciais."
      },
      {
        question: "É compatível com app?",
        answer: "Sim, possui controle via app para ajustes de purificação e aromaterapia."
      }
    ]
  },
  wiiser: {
    name: "AirPure Wiiser",
    price: "R$ 1.599",
    image: "./images/produtos/Wiiser.jpg",
    description: "O AirPure Wiiser é o modelo top de linha da nossa coleção, equipado com tecnologia avançada de purificação UV e ionização. Oferece o mais alto nível de purificação, eliminando vírus, bactérias e odores com eficiência excepcional, ideal para ambientes que exigem o ar mais puro possível.",
    specifications: [
      "Filtro HEPA H13 - Remove 99,97% das partículas",
      "Purificação UV",
      "Ionização",
      "Operação silenciosa (<28 dB)",
      "Consumo de energia: 45W",
      "Cobertura: até 60m²",
      "Dimensões: 32cm x 32cm x 55cm",
      "Peso: 9kg"
    ],
    benefits: [
      {
        icon: "🦠",
        title: "Purificação UV",
        description: "Eliminação de vírus e bactérias."
      },
      {
        icon: "⚡",
        title: "Ionização",
        description: "Neutralização de odores e partículas."
      },
      {
        icon: "💨",
        title: "Máxima Eficiência",
        description: "Tecnologia avançada para ar mais puro."
      },
      {
        icon: "🏢",
        title: "Grandes Ambientes",
        description: "Cobertura de até 60m²."
      }
    ],
    faq: [
      {
        question: "Como funciona o AirPure Wiiser?",
        answer: "O AirPure Wiiser utiliza filtro HEPA H13, purificação UV e ionização para máxima eficiência."
      },
      {
        question: "Qual o tamanho ideal do ambiente?",
        answer: "Ideal para ambientes de até 60m², como salas grandes ou escritórios."
      },
      {
        question: "Precisa de manutenção frequente?",
        answer: "Recomendamos limpeza mensal, substituição do filtro HEPA a cada 6-12 meses e manutenção da lâmpada UV."
      },
      {
        question: "É compatível com app?",
        answer: "Sim, possui controle avançado via app com monitoramento em tempo real."
      }
    ]
  }
};

// Function to get current product based on page
function getCurrentProduct() {
  const path = window.location.pathname;
  if (path.includes('compact.html')) return 'compact';
  if (path.includes('mini.html')) return 'mini';
  if (path.includes('silent.html')) return 'silent';
  if (path.includes('zen.html')) return 'zen';
  if (path.includes('wiiser.html')) return 'wiiser';
  if (path.includes('product.html')) return 'max';
  return 'max'; // default
}

// Get product data
const currentProduct = getCurrentProduct();
const productData = productsData[currentProduct];

// Function to populate the page with product data
function populateProductPage() {
  // Hero Section
  document.getElementById('productImage').src = productData.image;
  document.getElementById('productImage').alt = productData.name;
  document.getElementById('productName').textContent = productData.name;
  document.getElementById('productPrice').textContent = productData.price;

  // Description Section
  document.getElementById('productDescription').textContent = productData.description;

  // Specifications Section
  const specsTable = document.getElementById('productSpecifications');
  productData.specifications.forEach(spec => {
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.textContent = spec;
    tr.appendChild(td);
    specsTable.appendChild(tr);
  });

  // Benefits Section
  const benefitsGrid = document.getElementById('productBenefits');
  if (benefitsGrid) {
    productData.benefits.forEach(benefit => {
      const card = document.createElement('div');
      card.className = 'benefit-card';
      card.innerHTML = `
        <div class="benefit-icon">${benefit.icon}</div>
        <h3 class="benefit-title">${benefit.title}</h3>
        <p class="benefit-description">${benefit.description}</p>
      `;
      benefitsGrid.appendChild(card);
    });
  }

  // FAQ Section
  const faqContainer = document.getElementById('productFAQ');
  if (faqContainer) {
    productData.faq.forEach(item => {
      const faqItem = document.createElement('div');
      faqItem.className = 'faq-item';
      faqItem.innerHTML = `
        <button class="faq-question">${item.question}</button>
        <div class="faq-answer">
          <p>${item.answer}</p>
        </div>
      `;
      faqContainer.appendChild(faqItem);
    });
  }
}

// Initialize FAQ functionality
function initFAQ() {
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    question.addEventListener('click', () => {
      item.classList.toggle('active');
    });
  });
}

// Initialize buy button functionality
function initBuyButtons() {
  const buyNowBtn = document.getElementById('buyNowBtn');
  const fixedBuyButton = document.getElementById('fixedBuyButton');
  const addToCartBtn = document.getElementById('addToCartBtn');

  const handleBuyNow = () => {
    // Add to cart
    if (window.cartManager) {
      window.cartManager.addItem({
        id: productData.name + productData.price,
        name: productData.name,
        price: productData.price
      });
    } else {
      // Fallback if cartManager not available
      const cart = JSON.parse(localStorage.getItem('airpure-cart') || '[]');
      cart.push({
        id: productData.name + productData.price,
        name: productData.name,
        price: productData.price,
        quantity: 1
      });
      localStorage.setItem('airpure-cart', JSON.stringify(cart));
    }

    // Redirect to checkout
    window.location.href = './checkout.html';
  };

  const handleAddToCart = () => {
    // Add to cart only
    if (window.cartManager) {
      window.cartManager.addItem({
        id: productData.name + productData.price,
        name: productData.name,
        price: productData.price
      });
    } else {
      // Fallback if cartManager not available
      const cart = JSON.parse(localStorage.getItem('airpure-cart') || '[]');
      cart.push({
        id: productData.name + productData.price,
        name: productData.name,
        price: productData.price,
        quantity: 1
      });
      localStorage.setItem('airpure-cart', JSON.stringify(cart));
    }

    alert(`Produto ${productData.name} adicionado ao carrinho!`);
  };

  if (buyNowBtn) buyNowBtn.addEventListener('click', handleBuyNow);
  if (fixedBuyButton) fixedBuyButton.addEventListener('click', handleBuyNow);
  if (addToCartBtn) addToCartBtn.addEventListener('click', handleAddToCart);
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
  populateProductPage();
  initFAQ();
  initBuyButtons();
  initImageZoom();
  initFeaturesAccordion();
});

// Zoom on hover functionality
function initImageZoom() {
  const imgContainer = document.querySelector('.product-hero-image-container');
  const img = document.getElementById('productImage');

  if (!imgContainer || !img) return;

  // Add zoom functionality
  imgContainer.addEventListener('mouseenter', () => showZoom(img));
  imgContainer.addEventListener('mouseleave', () => hideZoom(img));
  imgContainer.addEventListener('mousemove', (e) => moveZoom(e, img));
}

function showZoom(img) {
  if (!img.src) return;

  // Apply zoom effect directly to the image
  img.style.transition = 'transform 0.1s ease';
  img.style.transform = 'scale(2)';
  img.style.cursor = 'zoom-out';
}

function hideZoom(img) {
  // Reset image to normal state
  img.style.transform = 'scale(1)';
  img.style.transformOrigin = 'center center';
  img.style.cursor = 'zoom-in';
}

function moveZoom(e, img) {
  const imgRect = img.getBoundingClientRect();

  // Calculate cursor position relative to image
  const x = e.clientX - imgRect.left;
  const y = e.clientY - imgRect.top;

  // Calculate percentage position for transform origin
  const xPercent = (x / imgRect.width) * 100;
  const yPercent = (y / imgRect.height) * 100;

  // Set transform origin to cursor position
  img.style.transformOrigin = `${xPercent}% ${yPercent}%`;
}

// Accordion functionality for features
function initFeaturesAccordion() {
  const featuresContainer = document.getElementById('productFeatures');
  if (!featuresContainer) return;

  // Example features - can be replaced with dynamic data if needed
  const features = [
    "Filtro HEPA H13 de alta eficiência",
    "Controle via app móvel",
    "Operação ultra silenciosa",
    "Indicador de troca de filtro",
    "Design compacto e moderno"
  ];

  features.forEach((feature, index) => {
    const item = document.createElement('div');
    item.className = 'faq-item';

    const button = document.createElement('button');
    button.className = 'faq-question';
    button.textContent = feature;
    button.setAttribute('aria-expanded', 'false');
    button.setAttribute('aria-controls', `feature-content-${index}`);

    const content = document.createElement('div');
    content.className = 'faq-answer';
    content.id = `feature-content-${index}`;
    content.style.maxHeight = '0px';

    const p = document.createElement('p');
    p.textContent = "Detalhes adicionais sobre esta característica.";

    content.appendChild(p);
    item.appendChild(button);
    item.appendChild(content);
    featuresContainer.appendChild(item);

    button.addEventListener('click', () => {
      const expanded = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', String(!expanded));
      item.classList.toggle('active');
      if (!expanded) {
        content.style.maxHeight = content.scrollHeight + "px";
      } else {
        content.style.maxHeight = "0px";
      }
    });
  });
}
