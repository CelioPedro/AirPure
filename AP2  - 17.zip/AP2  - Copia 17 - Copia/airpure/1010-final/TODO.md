# TODO: Refazer página do produto "Mini" - CONCLUÍDO

## Information Gathered
- Analisei as páginas de produto existentes (product.html para Max, zen.html para Zen, wiiser.html para Wiiser) e a mini.html atual.
- O padrão padrão inclui: cabeçalho com navegação e menu hambúrguer, seções principais (herói, descrição, especificações, recursos, avaliações), botão de compra fixo, rodapé e scripts.
- A mini.html atual estava incompleta em comparação com as outras (falta menu hambúrguer, estrutura de rodapé diferente).

## Plan
- [x] Sobrescrever mini.html com a estrutura completa de página de produto padrão (baseada em product.html ou zen.html).
- [x] Atualizar conteúdo específico do produto para Mini: título, meta, imagem, nome, preço, descrição, avaliações.

## Dependent Files to be edited
- [x] airpure/1010-final/mini.html

## Followup steps
- [x] Verificar se a página carrega corretamente.
