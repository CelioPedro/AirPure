# TODO - Implementação da Tela de Login

- [x] Criar arquivo login.html com estrutura HTML básica
- [x] Adicionar estilos CSS para layout centralizado, card arredondado, campos com ícones, botões e links
- [x] Implementar funções JavaScript: handleLogin, loginWith, showForgotPassword, showSignup
- [x] Garantir responsividade com media queries
- [ ] Testar abertura no navegador
