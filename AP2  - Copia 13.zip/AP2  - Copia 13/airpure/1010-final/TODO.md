# TODO: Adjust Product Image Proportions on Large Screens

## Tasks
- [x] Remove inline styles from img#productImage in product.html
- [x] Update CSS for .product-hero-image-container img in product-detail.css to preserve original image size
- [x] Update .product-hero-info to use justify-content: space-between to push buttons to bottom
- [ ] Verify changes on large screens to ensure image is centered without distortion

## Notes
- Preserve original image proportions without stretching or distortion.
- Use flexbox centering in container to position image.
- Test responsiveness on different screen sizes.
