/**
 * AirPure Website - Main JavaScript
 * Clean, modular, and maintainable code structure
 * @author BLACKBOXAI
 * @version 2.0.0
 */

// ========================================
// CONFIGURAÇÕES E CONSTANTES
// ========================================

const CONFIG = {
  // Seletores DOM
  SELECTORS: {
    // Navegação
    NAV_LINKS: 'a[href^="#"]',
    HEADER: '.header',
    HAMBURGER_TOGGLE: '.hamburger-toggle',
    HAMBURGER_NAV: '.hamburger-nav',
    DROPDOWN_TOGGLE: '.dropdown-toggle',
    DROPDOWN_MENU: '.dropdown-menu',
    CTA_BUTTON: '.cta-button',

    // Produtos
    FILTER_BUTTONS: '.filter-btn',
    PRODUCT_CARDS: '.product-card',
    PRODUCT_BUTTONS: '.product-button',
    PRODUCT_NAME: '.product-name',
    PRODUCT_PRICE: '.product-price',

    // Animações
    HERO_CONTENT: '.hero-content',
    HERO_IMAGE: '.hero-image',
  ANIMATED_ELEMENTS: '.fade-in, .tech-card, .benefit-card, .faq-item'
  },

  // Configurações de animação
  ANIMATION: {
    INTERSECTION_THRESHOLD: 0.1,
    INTERSECTION_ROOT_MARGIN: '0px 0px -50px 0px',
    STAGGER_DELAY: 0.1,
    PRODUCT_DELAY: 0,
    HERO_CONTENT_DELAY: 300,
    HERO_IMAGE_DELAY: 600,
    HERO_TRANSITION_DURATION: 0.8
  },

  // Configurações de UI
  UI: {
    SCROLL_THRESHOLD: 50,
    MOBILE_BREAKPOINT: 1020,
    PURCHASE_FEEDBACK_DURATION: 2000,
    HAMBURGER_RESET_DELAY: 300
  }
};

// ========================================
// UTILITÁRIOS GERAIS
// ========================================

/**
 * Utilitários para manipulação DOM e eventos
 */
class DOMUtils {
  /**
   * Cache de elementos DOM para performance
   * @private
   */
  static cache = new Map();

  /**
   * Obtém elemento do DOM com cache
   * @param {string} selector - Seletor CSS
   * @param {boolean} multiple - Se deve retornar múltiplos elementos
   * @returns {Element|NodeList|null}
   */
  static getElement(selector, multiple = false) {
    const cacheKey = `${selector}_${multiple}`;

    if (!this.cache.has(cacheKey)) {
      this.cache.set(
        cacheKey,
        multiple ? document.querySelectorAll(selector) : document.querySelector(selector)
      );
    }

    return this.cache.get(cacheKey);
  }

  /**
   * Adiciona múltiplos event listeners
   * @param {NodeList|Element} elements - Elementos
   * @param {string} event - Tipo do evento
   * @param {Function} handler - Função handler
   */
  static addEventListeners(elements, event, handler) {
    if (!elements) return;

    const elementArray = elements.length !== undefined ? elements : [elements];
    elementArray.forEach(element => {
      if (element) {
        element.addEventListener(event, handler);
      }
    });
  }

  /**
   * Remove classes de múltiplos elementos
   * @param {NodeList|Element} elements - Elementos
   * @param {string} className - Classe a remover
   */
  static removeClassFromAll(elements, className) {
    if (!elements) return;

    const elementArray = elements.length !== undefined ? elements : [elements];
    elementArray.forEach(element => {
      if (element) {
        element.classList.remove(className);
      }
    });
  }
}

// ========================================
// MÓDULO DE NAVEGAÇÃO
// ========================================

/**
 * Gerencia funcionalidades de navegação
 */
class NavigationManager {
  /**
   * Inicializa navegação suave
   */
  static initSmoothScrolling() {
    const navLinks = DOMUtils.getElement(CONFIG.SELECTORS.NAV_LINKS, true);

    DOMUtils.addEventListeners(navLinks, 'click', (e) => {
      e.preventDefault();
      const target = DOMUtils.getElement(e.target.getAttribute('href'));

      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  }
}

// ========================================
// MÓDULO DE PRODUTOS
// ========================================

/**
 * Gerencia funcionalidades relacionadas aos produtos
 */
class ProductManager {
  /**
   * Inicializa sistema de filtragem de produtos
   */
  static initProductFiltering() {
    const filterButtons = DOMUtils.getElement(CONFIG.SELECTORS.FILTER_BUTTONS, true);
    const productCards = DOMUtils.getElement(CONFIG.SELECTORS.PRODUCT_CARDS, true);

    if (!filterButtons || !productCards) return;

    DOMUtils.addEventListeners(filterButtons, 'click', (e) => {
      const clickedButton = e.target.closest(CONFIG.SELECTORS.FILTER_BUTTONS);
      if (!clickedButton) return;

      // Atualiza estado ativo dos botões
      DOMUtils.removeClassFromAll(filterButtons, 'active');
      clickedButton.classList.add('active');

      // Aplica filtro
      this.applyFilter(clickedButton.getAttribute('data-filter'), productCards);
    });
  }

  /**
   * Aplica filtro aos cards de produto
   * @param {string} filterValue - Valor do filtro
   * @param {NodeList} productCards - Cards de produto
   */
  static applyFilter(filterValue, productCards) {
    productCards.forEach(card => {
      // Limpa estilos inline para restaurar efeitos CSS
      card.style.opacity = '';
      card.style.transform = '';
      card.style.display = '';

      if (filterValue === 'all') {
        card.style.display = 'block';
        card.classList.add('animate');
      } else {
        const cardCategories = card.getAttribute('data-category');
        if (cardCategories && cardCategories.includes(filterValue)) {
          card.style.display = 'block';
          card.classList.add('animate');
        } else {
          card.style.display = 'none';
          card.classList.remove('animate');
        }
      }
    });
  }

  /**
   * Inicializa funcionalidade de compra
   */
  static initPurchaseFunctionality() {
    const productCards = DOMUtils.getElement(CONFIG.SELECTORS.PRODUCT_CARDS, true);
    const productButtons = DOMUtils.getElement(CONFIG.SELECTORS.PRODUCT_BUTTONS, true);

    // Removida funcionalidade de adicionar ao carrinho dos botões dos cards de produto
    // Os botões agora servem apenas para navegação ou abertura de modal

    // Handle product card clicks (open modal)
    DOMUtils.addEventListeners(productCards, 'click', function(e) {
      const productCard = this;
      if (!productCard) return;

      // Open product detail modal when clicking anywhere on the product card
      ProductDetailModal.open(productCard);
    });
  }
}

// ========================================
// MÓDULO DE ANIMAÇÕES
// ========================================

/**
 * Gerencia animações e efeitos visuais
 */
class AnimationManager {
  /**
   * Inicializa sistema de animações por scroll
   */
  static initScrollAnimations() {
    const observerOptions = {
      threshold: CONFIG.ANIMATION.INTERSECTION_THRESHOLD,
      rootMargin: CONFIG.ANIMATION.INTERSECTION_ROOT_MARGIN
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate');
        }
      });
    }, observerOptions);

    // Animações com delay escalonado para elementos gerais
    const animatedElements = DOMUtils.getElement(CONFIG.SELECTORS.ANIMATED_ELEMENTS, true);
    if (animatedElements) {
      animatedElements.forEach((el, index) => {
        el.style.transitionDelay = `${index * CONFIG.ANIMATION.STAGGER_DELAY}s`;
        observer.observe(el);
      });
    }

    // Animações consistentes para cards de produto
    const productCards = DOMUtils.getElement(CONFIG.SELECTORS.PRODUCT_CARDS, true);
    if (productCards) {
      productCards.forEach((el) => {
        el.style.transitionDelay = `${CONFIG.ANIMATION.PRODUCT_DELAY}s`;
        observer.observe(el);
      });
    }
  }

  /**
   * Inicializa animações do hero
   */
  static initHeroAnimations() {
    const heroContent = DOMUtils.getElement(CONFIG.SELECTORS.HERO_CONTENT);
    const heroImage = DOMUtils.getElement(CONFIG.SELECTORS.HERO_IMAGE);

    // Define estilos iniciais
    if (heroContent) {
      heroContent.style.opacity = '0';
      heroContent.style.transform = 'translateY(30px)';
      heroContent.style.transition = `all ${CONFIG.ANIMATION.HERO_TRANSITION_DURATION}s ease`;
    }

    if (heroImage) {
      heroImage.style.opacity = '0';
      heroImage.style.transform = 'translateY(30px)';
      heroImage.style.transition = `all ${CONFIG.ANIMATION.HERO_TRANSITION_DURATION}s ease`;
    }

    // Animações no load da página
    window.addEventListener('load', () => {
      setTimeout(() => {
        if (heroContent) {
          heroContent.style.opacity = '1';
          heroContent.style.transform = 'translateY(0)';
        }
      }, CONFIG.ANIMATION.HERO_CONTENT_DELAY);

      setTimeout(() => {
        if (heroImage) {
          heroImage.style.opacity = '1';
          heroImage.style.transform = 'translateY(0)';
        }
      }, CONFIG.ANIMATION.HERO_IMAGE_DELAY);
    });
  }
}

// ========================================
// MÓDULO DE COMPONENTES UI
// ========================================

/**
 * Gerencia componentes de interface do usuário
 */
class UIManager {
  /**
   * Inicializa comportamento do header no scroll
   */
  static initHeaderBehavior() {
    const header = DOMUtils.getElement(CONFIG.SELECTORS.HEADER);
    const ctaButton = DOMUtils.getElement(CONFIG.SELECTORS.CTA_BUTTON);

    // Only add scroll listener on homepage, not on product page
    if (!window.location.pathname.endsWith('index.html') && window.location.pathname !== '/') {
      if (header) {
        header.classList.add('scrolled');
        header.style.background = '#000'; // or any solid color you want
        header.style.backdropFilter = 'none';
      }
      return;
    }

    window.addEventListener('scroll', () => {
      const scrolled = window.scrollY > CONFIG.UI.SCROLL_THRESHOLD;

      if (header) {
        header.classList.toggle('scrolled', scrolled);
      }

      if (ctaButton) {
        const isMobile = window.innerWidth < CONFIG.UI.MOBILE_BREAKPOINT;
        ctaButton.classList.toggle('hidden', scrolled && isMobile);
      }
    });
  }

  /**
   * Inicializa menu hamburger
   */
  static initHamburgerMenu() {
    const hamburgerToggle = DOMUtils.getElement(CONFIG.SELECTORS.HAMBURGER_TOGGLE);
    const hamburgerNav = DOMUtils.getElement(CONFIG.SELECTORS.HAMBURGER_NAV);

    if (!hamburgerToggle || !hamburgerNav) return;

    // Toggle do menu
    hamburgerToggle.addEventListener('click', () => {
      const isOpen = hamburgerNav.classList.contains('show');

      if (isOpen) {
        this.closeHamburgerMenu(hamburgerNav, hamburgerToggle);
      } else {
        this.openHamburgerMenu(hamburgerNav, hamburgerToggle);
      }
    });

    // Fecha menu ao clicar fora
    document.addEventListener('click', (event) => {
      if (!hamburgerToggle.contains(event.target) && !hamburgerNav.contains(event.target)) {
        this.closeHamburgerMenu(hamburgerNav, hamburgerToggle);
      }
    });

    // Fecha menu ao clicar em link
    const navLinks = hamburgerNav.querySelectorAll('a');
    DOMUtils.addEventListeners(navLinks, 'click', () => {
      this.closeHamburgerMenu(hamburgerNav, hamburgerToggle);
    });
  }

  /**
   * Abre menu hamburger
   * @param {Element} nav - Elemento de navegação
   * @param {Element} toggle - Elemento toggle
   */
  static openHamburgerMenu(nav, toggle) {
    nav.classList.add('show');
    toggle.classList.add('open');
    document.body.classList.add('menu-open');
  }

  /**
   * Fecha menu hamburger
   * @param {Element} nav - Elemento de navegação
   * @param {Element} toggle - Elemento toggle
   */
  static closeHamburgerMenu(nav, toggle) {
    nav.classList.remove('show');
    toggle.classList.remove('open');
    document.body.classList.remove('menu-open');

    // Reseta animações para próxima abertura
    setTimeout(() => {
      const links = nav.querySelectorAll('a');
      links.forEach(link => {
        link.style.opacity = '0';
        link.style.transform = 'translateY(20px)';
      });
    }, CONFIG.UI.HAMBURGER_RESET_DELAY);
  }

  /**
   * Inicializa dropdown menu
   */
  static initDropdownMenu() {
    const dropdownToggle = DOMUtils.getElement(CONFIG.SELECTORS.DROPDOWN_TOGGLE);
    const dropdownMenu = DOMUtils.getElement(CONFIG.SELECTORS.DROPDOWN_MENU);

    if (!dropdownToggle || !dropdownMenu) return;

    // Toggle dropdown
    dropdownToggle.addEventListener('click', () => {
      dropdownMenu.classList.toggle('show');
    });

    // Fecha dropdown ao clicar fora
    document.addEventListener('click', (event) => {
      if (!dropdownToggle.contains(event.target) && !dropdownMenu.contains(event.target)) {
        dropdownMenu.classList.remove('show');
      }
    });
  }

  /**
   * Inicializa estado inicial dos componentes
   */
  static initInitialState() {
    const hamburgerNav = DOMUtils.getElement(CONFIG.SELECTORS.HAMBURGER_NAV);

    if (hamburgerNav) {
      const links = hamburgerNav.querySelectorAll('a');
      links.forEach(link => {
        link.style.opacity = '0';
        link.style.transform = 'translateY(20px)';
        link.style.display = 'block';
      });
    }
  }
}

/**
 * Product Detail Modal Manager
 */
class ProductDetailModal {
  static init() {
    this.modal = document.getElementById('productDetailModal');
    this.modalOverlay = document.getElementById('modalOverlay');
    this.modalCloseBtn = document.getElementById('modalCloseBtn');
    this.modalProductImage = document.getElementById('modalProductImage');
    this.modalProductName = document.getElementById('productDetailTitle');
    this.modalProductDescription = document.querySelector('.modal-product-description');
    this.modalProductPrice = document.querySelector('.modal-product-price');
    this.modalAddToCartBtn = document.getElementById('modalAddToCartBtn');
    this.modalCoverage = document.getElementById('modalCoverage');
    this.modalFilter = document.getElementById('modalFilter');
    this.modalNoise = document.getElementById('modalNoise');

    this.attachEventListeners();
  }

  static attachEventListeners() {
    // Close modal events
    this.modalCloseBtn.addEventListener('click', () => this.close());
    this.modalOverlay.addEventListener('click', () => this.close());

    // Add to cart
    this.modalAddToCartBtn.addEventListener('click', () => this.addToCart());

    // Image zoom
    this.modalProductImage.addEventListener('mouseenter', () => this.showZoom());
    this.modalProductImage.addEventListener('mouseleave', () => this.hideZoom());
    this.modalProductImage.addEventListener('mousemove', (e) => this.moveZoom(e));

    // ESC key to close
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.modal.classList.contains('show')) {
        this.close();
      }
    });
  }

  static open(productCard) {
    if (!this.modal) {
      this.init();
    }

    // Get product data
    const image = productCard.querySelector('.product-image img')?.src || '';
    const name = productCard.querySelector('.product-name')?.textContent || 'Produto';
    const description = productCard.querySelector('.product-description')?.textContent || 'Descrição não disponível';
    const price = productCard.querySelector('.product-price')?.textContent || 'R$ 0,00';

    // Get product specifications (you can customize these based on product type)
    const coverage = this.getProductSpec(name, 'coverage');
    const filter = this.getProductSpec(name, 'filter');
    const noise = this.getProductSpec(name, 'noise');

    // Populate modal
    this.modalProductImage.src = image;
    this.modalProductImage.alt = name;
    this.modalProductName.textContent = name;
    this.modalProductDescription.textContent = description;
    this.modalProductPrice.textContent = price;

    // Populate specifications
    if (this.modalCoverage) this.modalCoverage.textContent = coverage;
    if (this.modalFilter) this.modalFilter.textContent = filter;
    if (this.modalNoise) this.modalNoise.textContent = noise;

    // Show modal
    this.modal.classList.add('show');
    document.body.style.overflow = 'hidden';

    // Focus management
    this.modalCloseBtn.focus();
  }

  /**
   * Get product specification based on product name and spec type
   * @param {string} productName - Name of the product
   * @param {string} specType - Type of specification (coverage, filter, noise)
   * @returns {string} Specification value
   */
  static getProductSpec(productName, specType) {
    // Product specifications database (you can expand this with more products)
    const specs = {
      'AirPure Compact': {
        coverage: 'Até 25m²',
        filter: 'HEPA + Carvão Ativado',
        noise: '≤25 dB'
      },
      'AirPure Mini': {
        coverage: 'Até 20m²',
        filter: 'HEPA + Carvão Ativado',
        noise: '≤20 dB'
      },
      'AirPure Silent': {
        coverage: 'Até 40m²',
        filter: 'HEPA + Carvão Ativado',
        noise: '≤25 dB'
      },
      'AirPure Zen': {
        coverage: 'Até 60m²',
        filter: 'HEPA + Carvão Ativado + Aromaterapia',
        noise: '≤30 dB'
      },
      'AirPure Max': {
        coverage: 'Até 80m²',
        filter: 'HEPA H13 + Carvão Ativado',
        noise: '≤35 dB'
      },
      'AirPure Wiiser': {
        coverage: 'Até 100m²',
        filter: 'HEPA H13 + Carvão Ativado + UV + Ionização',
        noise: '≤40 dB'
      }
    };

    // Find matching product or use default
    const productSpecs = specs[productName] || {
      coverage: 'Até 50m²',
      filter: 'HEPA + Carvão Ativado',
      noise: '≤30 dB'
    };

    return productSpecs[specType] || 'N/A';
  }

  static close() {
    this.modal.classList.remove('show');
    document.body.style.overflow = '';
    this.hideZoom();
  }



  static addToCart() {
    const name = this.modalProductName.textContent;
    const price = this.modalProductPrice.textContent;

    // Add single item to cart
    window.cartManager.addItem({
      id: name + price,
      name,
      price
    });

    // Feedback
    this.modalAddToCartBtn.textContent = 'Adicionado!';
    this.modalAddToCartBtn.style.background = 'linear-gradient(135deg, #27ae60, #2ecc71)';

    setTimeout(() => {
      this.modalAddToCartBtn.textContent = 'Adicionar ao Carrinho';
      this.modalAddToCartBtn.style.background = '';
    }, 2000);

    // Close modal after short delay
    setTimeout(() => this.close(), 1000);
  }

  static showZoom() {
    if (!this.modalProductImage.src) return;

    // Apply zoom effect directly to the image
    this.modalProductImage.style.transition = 'transform 0.1s ease';
    this.modalProductImage.style.transform = 'scale(2)';
    this.modalProductImage.style.cursor = 'zoom-out';
  }

  static hideZoom() {
    // Reset image to normal state
    this.modalProductImage.style.transform = 'scale(1)';
    this.modalProductImage.style.transformOrigin = 'center center';
    this.modalProductImage.style.cursor = 'zoom-in';
  }

  static moveZoom(e) {
    const imgRect = this.modalProductImage.getBoundingClientRect();

    // Calculate cursor position relative to image
    const x = e.clientX - imgRect.left;
    const y = e.clientY - imgRect.top;

    // Calculate percentage position for transform origin
    const xPercent = (x / imgRect.width) * 100;
    const yPercent = (y / imgRect.height) * 100;

    // Set transform origin to cursor position
    this.modalProductImage.style.transformOrigin = `${xPercent}% ${yPercent}%`;
  }
}

/**
 * Login Modal Manager
 */
class LoginModal {
  static init() {
    this.modal = document.getElementById('loginModal');
    this.modalOverlay = document.getElementById('loginModalOverlay');
    this.modalClose = document.getElementById('loginModalClose');

    if (!this.modal) return;

    this.attachEventListeners();
  }

  static attachEventListeners() {
    // Close modal events
    this.modalClose.addEventListener('click', () => this.close());
    this.modalOverlay.addEventListener('click', () => this.close());

    // ESC key to close
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.modal.classList.contains('show')) {
        this.close();
      }
    });
  }

  static open() {
    if (!this.modal) {
      this.init();
    }

    // Show modal
    this.modal.classList.add('show');
    document.body.style.overflow = 'hidden';

    // Focus management
    this.modalClose.focus();
  }

  static close() {
    this.modal.classList.remove('show');
    document.body.style.overflow = '';
  }
}

// ========================================
// FUNÇÕES GLOBAIS PARA LOGIN MODAL
// ========================================

/**
 * Abre o modal de login
 */
function openLoginModal() {
  LoginModal.open();
}

/**
 * Trata o envio do formulário de login
 * @param {Event} event - Evento do formulário
 */
function handleLogin(event) {
  event.preventDefault();

  const form = event.target;
  const email = form.querySelector('input[type="email"]').value;
  const password = form.querySelector('input[type="password"]').value;

  // Simulação de login (substitua por lógica real)
  if (email && password) {
    alert('Login realizado com sucesso!');
    LoginModal.close();
    form.reset();
  } else {
    alert('Por favor, preencha todos os campos.');
  }
}

/**
 * Mostra modal de recuperação de senha
 */
function showForgotPassword() {
  alert('Funcionalidade de recuperação de senha em desenvolvimento.');
}

/**
 * Mostra modal de cadastro
 */
function showSignup() {
  alert('Funcionalidade de cadastro em desenvolvimento.');
}

/**
 * Trata login com provedor alternativo
 * @param {string} provider - Nome do provedor (Google, Apple, Passkey)
 */
function loginWith(provider) {
  alert(`Login com ${provider} em desenvolvimento.`);
}

// ========================================
// INICIALIZAÇÃO DA APLICAÇÃO
// ========================================

/**
 * Inicializa todos os módulos da aplicação
 */
function initApp() {
  try {
    // Navegação
    NavigationManager.initSmoothScrolling();

    // Produtos
    ProductManager.initProductFiltering();
    ProductManager.initPurchaseFunctionality();

    // Animações
    AnimationManager.initScrollAnimations();
    AnimationManager.initHeroAnimations();

    // UI Components
    UIManager.initHeaderBehavior();
    UIManager.initHamburgerMenu();
    UIManager.initDropdownMenu();
    UIManager.initInitialState();

    console.log('AirPure website initialized successfully');
  } catch (error) {
    console.error('Error initializing AirPure website:', error);
  }
}

class FAQManager {
  static init() {
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
      const question = item.querySelector('.faq-question');
      question.addEventListener('click', () => {
        item.classList.toggle('active');
      });
    });
  }
}

/**
 * Off-canvas Shopping Cart Manager
 */
class CartManager {
  constructor() {
    this.cart = [];
    this.cartIcon = document.querySelector('.cart-icon');
    this.body = document.body;
    this.createCartElements();
    this.attachEventListeners();
  }

  createCartElements() {
    // Create overlay
    this.overlay = document.createElement('div');
    this.overlay.className = 'cart-overlay';
    this.overlay.style.position = 'fixed';
    this.overlay.style.top = '0';
    this.overlay.style.left = '0';
    this.overlay.style.width = '100vw';
    this.overlay.style.height = '100vh';
    this.overlay.style.backgroundColor = 'rgba(0,0,0,0.5)';
    this.overlay.style.opacity = '0';
    this.overlay.style.visibility = 'hidden';
    this.overlay.style.transition = 'opacity 0.3s ease';
    this.overlay.style.zIndex = '999';

    // Create cart container
    this.cartContainer = document.createElement('aside');
    this.cartContainer.className = 'offcanvas-cart';
    this.cartContainer.style.position = 'fixed';
    this.cartContainer.style.top = '0';
    this.cartContainer.style.right = '-400px';
    this.cartContainer.style.width = '350px';
    this.cartContainer.style.height = '100vh';
    this.cartContainer.style.backgroundColor = '#fff';
    this.cartContainer.style.boxShadow = '-2px 0 8px rgba(0,0,0,0.2)';
    this.cartContainer.style.transition = 'right 0.3s ease';
    this.cartContainer.style.zIndex = '1000';
    this.cartContainer.style.display = 'flex';
    this.cartContainer.style.flexDirection = 'column';

    // Header with close button
    const header = document.createElement('div');
    header.style.display = 'flex';
    header.style.justifyContent = 'space-between';
    header.style.alignItems = 'center';
    header.style.padding = '1rem';
    header.style.borderBottom = '1px solid #ddd';

    const title = document.createElement('h2');
    title.textContent = 'Carrinho de Compras';
    title.style.margin = '0';
    title.style.fontSize = '1.25rem';
    title.style.fontWeight = '600';
    title.style.color = '#333';

    this.closeButton = document.createElement('button');
    this.closeButton.textContent = '×';
    this.closeButton.setAttribute('aria-label', 'Fechar carrinho');
    this.closeButton.style.fontSize = '1.5rem';
    this.closeButton.style.background = 'none';
    this.closeButton.style.border = 'none';
    this.closeButton.style.cursor = 'pointer';
    this.closeButton.style.color = '#333';

    header.appendChild(title);
    header.appendChild(this.closeButton);

    // Cart items container
    this.itemsContainer = document.createElement('div');
    this.itemsContainer.style.flex = '1';
    this.itemsContainer.style.overflowY = 'auto';
    this.itemsContainer.style.padding = '1rem';

    // Total and checkout
    const footer = document.createElement('div');
    footer.style.padding = '1rem';
    footer.style.borderTop = '1px solid #ddd';

    this.totalPriceEl = document.createElement('div');
    this.totalPriceEl.style.fontWeight = '600';
    this.totalPriceEl.style.marginBottom = '1rem';
    this.totalPriceEl.textContent = 'Total: R$ 0,00';

    this.checkoutButton = document.createElement('button');
    this.checkoutButton.textContent = 'Finalizar Compra';
    this.checkoutButton.style.width = '100%';
    this.checkoutButton.style.padding = '0.75rem';
    this.checkoutButton.style.backgroundColor = '#374151';
    this.checkoutButton.style.color = 'white';
    this.checkoutButton.style.border = 'none';
    this.checkoutButton.style.borderRadius = '0.5rem';
    this.checkoutButton.style.cursor = 'pointer';
    this.checkoutButton.style.fontWeight = '600';

    footer.appendChild(this.totalPriceEl);
    footer.appendChild(this.checkoutButton);

    this.cartContainer.appendChild(header);
    this.cartContainer.appendChild(this.itemsContainer);
    this.cartContainer.appendChild(footer);

    this.body.appendChild(this.overlay);
    this.body.appendChild(this.cartContainer);
  }

  attachEventListeners() {
    this.cartIcon.addEventListener('click', () => this.openCart());
    this.closeButton.addEventListener('click', () => this.closeCart());
    this.overlay.addEventListener('click', () => this.closeCart());
    this.checkoutButton.addEventListener('click', () => this.checkout());

    // Delegate remove item buttons
    this.itemsContainer.addEventListener('click', (e) => {
      if (e.target.classList.contains('remove-item')) {
        const index = e.target.getAttribute('data-index');
        this.removeItem(parseInt(index));
      }

      // Handle quantity increase/decrease buttons
      if (e.target.classList.contains('quantity-btn')) {
        const index = parseInt(e.target.getAttribute('data-index'));
        if (e.target.classList.contains('increase')) {
          this.updateQuantity(index, 1);
        } else if (e.target.classList.contains('decrease')) {
          this.updateQuantity(index, -1);
        }
      }
    });

    // Handle quantity input changes
    this.itemsContainer.addEventListener('change', (e) => {
      if (e.target.classList.contains('quantity-input')) {
        const index = parseInt(e.target.getAttribute('data-index'));
        const newQuantity = parseInt(e.target.value) || 1;
        this.setQuantity(index, newQuantity);
      }
    });

    // Prevent negative values in quantity input
    this.itemsContainer.addEventListener('input', (e) => {
      if (e.target.classList.contains('quantity-input')) {
        const value = parseInt(e.target.value);
        if (value < 1 || isNaN(value)) {
          e.target.value = 1;
        }
      }
    });
  }

  openCart() {
    // Store current scroll position
    this.scrollPosition = window.pageYOffset || document.documentElement.scrollTop;

    // Remove padding-right from #home when cart opens
    const homeSection = document.getElementById('home');
    if (homeSection) {
      homeSection.style.paddingRight = '0';
    }

    // Prevent body scroll and compensate for scrollbar with fixed 15px padding
    document.body.style.overflow = 'hidden';
    document.body.style.position = 'fixed';
    document.body.style.top = `-${this.scrollPosition}px`;
    document.body.style.width = '100%';
    
    this.overlay.style.visibility = 'visible';
    this.overlay.style.opacity = '1';
    this.cartContainer.style.right = '0';
    this.renderCart();
  }

  closeCart() {
    this.overlay.style.opacity = '0';
    this.overlay.style.visibility = 'hidden';
    this.cartContainer.style.right = '-400px';

    // Restore padding-right on #home when cart closes
    const homeSection = document.getElementById('home');
    if (homeSection) {
      homeSection.style.paddingRight = '';
    }

    // Restore body scroll and position
    document.body.style.overflow = '';
    document.body.style.position = '';
    document.body.style.top = '';
    document.body.style.width = '';
    document.body.style.paddingRight = '';

    // Restore scroll position
    if (this.scrollPosition !== undefined) {
      window.scrollTo(0, this.scrollPosition);
      this.scrollPosition = undefined;
    }
  }

  addItem(product) {
    const existingIndex = this.cart.findIndex(item => item.id === product.id);
    if (existingIndex !== -1) {
      this.cart[existingIndex].quantity += 1;
    } else {
      this.cart.push({...product, quantity: 1});
    }
    this.renderCart();
  }

  removeItem(index) {
    this.cart.splice(index, 1);
    this.renderCart();
  }

  updateQuantity(index, change) {
    if (this.cart[index]) {
      this.cart[index].quantity = Math.max(1, this.cart[index].quantity + change);
      this.renderCart();
    }
  }

  setQuantity(index, quantity) {
    if (this.cart[index]) {
      this.cart[index].quantity = Math.max(1, quantity);
      this.renderCart();
    }
  }

  calculateTotal() {
    return this.cart.reduce((total, item) => {
      const priceNumber = parseFloat(item.price.replace(/[^\d,]/g, '').replace(',', '.')) || 0;
      return total + priceNumber * item.quantity;
    }, 0);
  }

  formatPrice(value) {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }

  renderCart() {
    this.itemsContainer.innerHTML = '';
    if (this.cart.length === 0) {
      const emptyMessage = document.createElement('p');
      emptyMessage.textContent = 'Seu carrinho está vazio.';
      emptyMessage.style.textAlign = 'center';
      emptyMessage.style.color = '#666';
      this.itemsContainer.appendChild(emptyMessage);
      this.totalPriceEl.textContent = 'Total: R$ 0,00';
      return;
    }

    this.cart.forEach((item, index) => {
      const itemEl = document.createElement('div');
      itemEl.style.display = 'flex';
      itemEl.style.justifyContent = 'space-between';
      itemEl.style.alignItems = 'center';
      itemEl.style.marginBottom = '1rem';
      itemEl.style.borderBottom = '1px solid #eee';
      itemEl.style.paddingBottom = '1rem';

      const infoEl = document.createElement('div');
      infoEl.style.flex = '1';

      const nameEl = document.createElement('p');
      nameEl.textContent = item.name;
      nameEl.style.margin = '0 0 0.5rem 0';
      nameEl.style.fontWeight = '600';

      // Quantity controls
      const quantityControls = document.createElement('div');
      quantityControls.style.display = 'flex';
      quantityControls.style.alignItems = 'center';
      quantityControls.style.gap = '0.5rem';

      const decreaseBtn = document.createElement('button');
      decreaseBtn.textContent = '-';
      decreaseBtn.className = 'quantity-btn decrease';
      decreaseBtn.setAttribute('data-index', index);
      decreaseBtn.style.width = '30px';
      decreaseBtn.style.height = '30px';
      decreaseBtn.style.border = '1px solid #ddd';
      decreaseBtn.style.background = '#f9f9f9';
      decreaseBtn.style.cursor = 'pointer';
      decreaseBtn.style.borderRadius = '4px';
      decreaseBtn.style.display = 'flex';
      decreaseBtn.style.alignItems = 'center';
      decreaseBtn.style.justifyContent = 'center';
      decreaseBtn.style.fontSize = '1.2rem';
      decreaseBtn.style.fontWeight = 'bold';

      const quantityInput = document.createElement('input');
      quantityInput.type = 'number';
      quantityInput.value = item.quantity;
      quantityInput.min = '1';
      quantityInput.className = 'quantity-input';
      quantityInput.setAttribute('data-index', index);
      quantityInput.style.width = '60px';
      quantityInput.style.textAlign = 'center';
      quantityInput.style.border = '1px solid #ddd';
      quantityInput.style.borderRadius = '4px';
      quantityInput.style.padding = '0.25rem';
      quantityInput.style.fontSize = '1rem';

      const increaseBtn = document.createElement('button');
      increaseBtn.textContent = '+';
      increaseBtn.className = 'quantity-btn increase';
      increaseBtn.setAttribute('data-index', index);
      increaseBtn.style.width = '30px';
      increaseBtn.style.height = '30px';
      increaseBtn.style.border = '1px solid #ddd';
      increaseBtn.style.background = '#f9f9f9';
      increaseBtn.style.cursor = 'pointer';
      increaseBtn.style.borderRadius = '4px';
      increaseBtn.style.display = 'flex';
      increaseBtn.style.alignItems = 'center';
      increaseBtn.style.justifyContent = 'center';
      increaseBtn.style.fontSize = '1.2rem';
      increaseBtn.style.fontWeight = 'bold';

      quantityControls.appendChild(decreaseBtn);
      quantityControls.appendChild(quantityInput);
      quantityControls.appendChild(increaseBtn);

      infoEl.appendChild(nameEl);
      infoEl.appendChild(quantityControls);

      const priceEl = document.createElement('p');
      priceEl.textContent = this.formatPrice(parseFloat(item.price.replace(/[^\d,]/g, '').replace(',', '.')) * item.quantity);
      priceEl.style.margin = '0 1rem 0 0';
      priceEl.style.fontWeight = '600';
      priceEl.style.fontSize = '1.1rem';

      const removeBtn = document.createElement('button');
      removeBtn.textContent = 'Remover';
      removeBtn.className = 'remove-item';
      removeBtn.setAttribute('data-index', index);
      removeBtn.style.background = 'none';
      removeBtn.style.border = 'none';
      removeBtn.style.color = '#e53e3e';
      removeBtn.style.cursor = 'pointer';
      removeBtn.style.fontSize = '0.9rem';

      itemEl.appendChild(infoEl);
      itemEl.appendChild(priceEl);
      itemEl.appendChild(removeBtn);

      this.itemsContainer.appendChild(itemEl);
    });

    const total = this.calculateTotal();
    this.totalPriceEl.textContent = `Total: ${this.formatPrice(total)}`;
  }

  checkout() {
    if (this.cart.length === 0) {
      alert('Seu carrinho está vazio.');
      return;
    }
    alert('Checkout realizado com sucesso! Obrigado pela compra.');
    this.cart = [];
    this.closeCart();
  }
}

// Inicializa quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
  initApp();
  FAQManager.init();
  window.cartManager = new CartManager();
  ProductDetailModal.init();
});
