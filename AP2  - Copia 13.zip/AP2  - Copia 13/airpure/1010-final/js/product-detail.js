// Product Detail Page JavaScript
// Holds product data in variables for reusability

// Product Data Variables
const productData = {
  name: "AirPure Max",
  price: "R$ 1.299",
  image: "./images/produtos/Max.jpg",
  description: "O AirPure Max é o purificador premium da linha, equipado com filtro HEPA H13 de alta eficiência, capaz de remover 99,97% das partículas de 0,3 mícrons, incluindo vírus, bactérias e alérgenos. Com controle inteligente via app, operação silenciosa e design moderno, ele garante ar puro e saudável para ambientes maiores, como salas de estar ou escritórios.",
  specifications: [
    "Filtro HEPA H13 - Remove 99,97% das partículas",
    "Controle via app móvel",
    "Operação ultra silenciosa (<25 dB)",
    "Consumo de energia: 50W",
    "Cobertura: até 50m²",
    "Dimensões: 30cm x 30cm x 50cm",
    "Peso: 8kg"
  ],
  benefits: [
    {
      icon: "✨",
      title: "Design Premium",
      description: "Estética minimalista que complementa qualquer ambiente moderno."
    },
    {
      icon: "🏠",
      title: "Máximo Conforto",
      description: "Operação silenciosa e eficiente para seu bem-estar diário."
    },
    {
      icon: "💨",
      title: "Ar Puro",
      description: "Eliminação de 99,97% dos poluentes, alérgenos e partículas nocivas."
    },
    {
      icon: "🌱",
      title: "Sustentabilidade",
      description: "Tecnologia eco-friendly com baixo consumo energético."
    }
  ],
  faq: [
    {
      question: "Como funciona o AirPure Max?",
      answer: "O AirPure Max utiliza filtros avançados HEPA H13 para capturar partículas nocivas, com sensores inteligentes que ajustam a purificação conforme a qualidade do ar."
    },
    {
      question: "Qual o tamanho ideal do ambiente?",
      answer: "Ideal para ambientes de até 50m², como salas de estar, quartos grandes ou pequenos escritórios."
    },
    {
      question: "Precisa de manutenção frequente?",
      answer: "Recomendamos limpeza mensal dos filtros externos e substituição do filtro HEPA a cada 6-12 meses, dependendo do uso."
    },
    {
      question: "É compatível com app?",
      answer: "Sim, possui controle total via aplicativo móvel para iOS e Android, permitindo ajustes remotos e monitoramento em tempo real."
    }
  ]
};

// Function to populate the page with product data
function populateProductPage() {
  // Hero Section
  document.getElementById('productImage').src = productData.image;
  document.getElementById('productImage').alt = productData.name;
  document.getElementById('productName').textContent = productData.name;
  document.getElementById('productPrice').textContent = productData.price;

  // Description Section
  document.getElementById('productDescription').textContent = productData.description;

  // Specifications Section
  const specsTable = document.getElementById('productSpecifications');
  productData.specifications.forEach(spec => {
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.textContent = spec;
    tr.appendChild(td);
    specsTable.appendChild(tr);
  });

  // Benefits Section
  const benefitsGrid = document.getElementById('productBenefits');
  productData.benefits.forEach(benefit => {
    const card = document.createElement('div');
    card.className = 'benefit-card';
    card.innerHTML = `
      <div class="benefit-icon">${benefit.icon}</div>
      <h3 class="benefit-title">${benefit.title}</h3>
      <p class="benefit-description">${benefit.description}</p>
    `;
    benefitsGrid.appendChild(card);
  });

  // FAQ Section
  const faqContainer = document.getElementById('productFAQ');
  productData.faq.forEach(item => {
    const faqItem = document.createElement('div');
    faqItem.className = 'faq-item';
    faqItem.innerHTML = `
      <button class="faq-question">${item.question}</button>
      <div class="faq-answer">
        <p>${item.answer}</p>
      </div>
    `;
    faqContainer.appendChild(faqItem);
  });
}

// Initialize FAQ functionality
function initFAQ() {
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    question.addEventListener('click', () => {
      item.classList.toggle('active');
    });
  });
}

// Initialize buy button functionality
function initBuyButtons() {
  const buyNowBtn = document.getElementById('buyNowBtn');
  const fixedBuyButton = document.getElementById('fixedBuyButton');
  const addToCartBtn = document.getElementById('addToCartBtn');

  const handleBuy = () => {
    alert(`Produto ${productData.name} adicionado ao carrinho!`);
    // Here you could integrate with cart functionality
  };

  buyNowBtn.addEventListener('click', handleBuy);
  fixedBuyButton.addEventListener('click', handleBuy);
  if (addToCartBtn) {
    addToCartBtn.addEventListener('click', () => {
      alert(`Produto ${productData.name} adicionado ao carrinho!`);
      // Here you could integrate with cart functionality
    });
  }
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
  populateProductPage();
  initFAQ();
  initBuyButtons();
  initImageZoom();
  initFeaturesAccordion();
});

// Zoom on hover functionality
function initImageZoom() {
  const imgContainer = document.querySelector('.product-hero-image-container');
  const img = document.getElementById('productImage');

  if (!imgContainer || !img) return;

  // Add zoom functionality
  imgContainer.addEventListener('mouseenter', () => showZoom(img));
  imgContainer.addEventListener('mouseleave', () => hideZoom(img));
  imgContainer.addEventListener('mousemove', (e) => moveZoom(e, img));
}

function showZoom(img) {
  if (!img.src) return;

  // Apply zoom effect directly to the image
  img.style.transition = 'transform 0.1s ease';
  img.style.transform = 'scale(2)';
  img.style.cursor = 'zoom-out';
}

function hideZoom(img) {
  // Reset image to normal state
  img.style.transform = 'scale(1)';
  img.style.transformOrigin = 'center center';
  img.style.cursor = 'zoom-in';
}

function moveZoom(e, img) {
  const imgRect = img.getBoundingClientRect();

  // Calculate cursor position relative to image
  const x = e.clientX - imgRect.left;
  const y = e.clientY - imgRect.top;

  // Calculate percentage position for transform origin
  const xPercent = (x / imgRect.width) * 100;
  const yPercent = (y / imgRect.height) * 100;

  // Set transform origin to cursor position
  img.style.transformOrigin = `${xPercent}% ${yPercent}%`;
}

// Accordion functionality for features
function initFeaturesAccordion() {
  const featuresContainer = document.getElementById('productFeatures');
  if (!featuresContainer) return;

  // Example features - can be replaced with dynamic data if needed
  const features = [
    "Filtro HEPA H13 de alta eficiência",
    "Controle via app móvel",
    "Operação ultra silenciosa",
    "Indicador de troca de filtro",
    "Design compacto e moderno"
  ];

  features.forEach((feature, index) => {
    const item = document.createElement('div');
    item.className = 'faq-item';

    const button = document.createElement('button');
    button.className = 'faq-question';
    button.textContent = feature;
    button.setAttribute('aria-expanded', 'false');
    button.setAttribute('aria-controls', `feature-content-${index}`);

    const content = document.createElement('div');
    content.className = 'faq-answer';
    content.id = `feature-content-${index}`;
    content.style.maxHeight = '0px';

    const p = document.createElement('p');
    p.textContent = "Detalhes adicionais sobre esta característica.";

    content.appendChild(p);
    item.appendChild(button);
    item.appendChild(content);
    featuresContainer.appendChild(item);

    button.addEventListener('click', () => {
      const expanded = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', String(!expanded));
      item.classList.toggle('active');
      if (!expanded) {
        content.style.maxHeight = content.scrollHeight + "px";
      } else {
        content.style.maxHeight = "0px";
      }
    });
  });
}
